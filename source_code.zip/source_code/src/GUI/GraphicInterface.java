package GUI;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.io.File;

import javax.swing.*;

import filesGeneration.SettingFilesGenerator;
import solutions.Damig_MaximumEnergy.DAMiG_MaxEnergy;
import solutions.Damig_MinimumSpanningTree.DAMiG_MST;
import solutions.Damig_ShortestPathTree.DAMiG_SPT;
import solutions.NoInterGroupAggregation.EERS;
import solutions.ttama.TTAMA;


public class GraphicInterface extends JPanel implements ActionListener{

/* ATTRIBUTES */
/* GUI Components */
JFrame firstFrame;
JFrame secondFrame;
JButton button_browser;
JButton button_settings;
JButton button_run;
JButton openButton;
JButton saveButton;
JComboBox combo_solutions;
JComboBox combo_repts;
JFormattedTextField number_nodes;
JFormattedTextField ID;
JTextArea textAreaRunning;
JScrollPane scrollAreaRunning;
JFileChooser fc;
NetworkGUI netGUI;

/* Other */
boolean run_control;
boolean GUIfinished=false;
int n_repts;
int n_nodes;
File file;
String selected_solution;
String simString;


/* GETS AND SETS METHODS */
public int getNsize() {
	return n_nodes;
}

public void writeToRunningFrame(String s) {
	textAreaRunning.append(s+"\n");
}

public String getPath() {
	return file.getAbsolutePath()+"/AggregationTool/"+simString+"/" ;
}

public String getSimString() {
	return simString;
}

public boolean getRun_control() {
	return run_control ;
}

public void setRun_control(boolean control) {
	run_control = control;
}
	
public boolean isCreated() {
	return GUIfinished;
}


/* OTHER METHODS */
public void createFirstGUI() {
	 firstFrame = new JFrame();
	 firstFrame.setForeground(Color.WHITE);
	 firstFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	 firstFrame.setLocation(new Point(500,200));
	 firstFrame.setSize(new Dimension(300, 500));
	 firstFrame.setTitle("Aggregation Tool V2.0");
	 
	/* ---- TEXT AREA FOR SIMULATION ID ---- */		
	JLabel simID = new JLabel("Simulation Label:");	
	firstFrame.add(simID);
	ID = new JFormattedTextField();
	ID.setColumns(10);
	firstFrame.add(ID);
	 
	/* ---- COMBO BOX SOLUTIONS ---- */
	JLabel label1 = new JLabel("Select Solution:");
	String[] solutions = { "TTAMA", "DAMiG_MST", "DAMiG_Energy", "EERS", "DAMiG_SPT" };
	combo_solutions = new JComboBox(solutions);
	combo_solutions.setSelectedIndex(0);
	firstFrame.add(label1);
	firstFrame.add(combo_solutions);
	
	/* ---- COMBO BOX REPETIONS ---- */		
	JLabel label2 = new JLabel("Select Number of Repetions:");
	String[] repts = { "1", "2", "3", "4", "5","6", "7", "8", "9", "10"};
	combo_repts = new JComboBox(repts);
	combo_repts.setSelectedIndex(0);
	firstFrame.add(label2);
	firstFrame.add(combo_repts);
	
	/* ---- TEXT AREA FOR NUMBER OF NODES ---- */		
	JLabel label3 = new JLabel("Number of Nodes:");	
	firstFrame.add(label3);
	number_nodes = new JFormattedTextField();
	number_nodes.setColumns(5);
	firstFrame.add(number_nodes);
	
	/* ---- BUTTON BROWSER ---- */
	 button_browser = new JButton();
	 button_browser.setText("SAVE & SETTINGS DIR");
	 button_browser.setBackground(Color.BLUE);
	 firstFrame.add(button_browser);
	 button_browser.addActionListener(this);		
	
	
	/* ---- BUTTON LOAD ---- */
	 button_settings = new JButton();
	 button_settings.setText("CREATE SETTINGS");
	 button_settings.setBackground(Color.BLUE);
	 firstFrame.add(button_settings);
	 button_settings.addActionListener(this);
	 button_settings.setEnabled(false);
	
	
	/* ---- BUTTON RUN ---- */
	 button_run = new JButton();
	 button_run.setText("RUN");
	 button_run.setBackground(Color.BLUE);
	 firstFrame.add(button_run);
	 setRun_control(false);
	 button_run.setEnabled(false);
	 button_run.addActionListener(this);
	
	/* ---- LAYOUT ---- */		
	 firstFrame.setLayout(new FlowLayout());
	 firstFrame.setVisible(true);
}


public void createSecondGUI() {
	 secondFrame = new JFrame();
	 secondFrame.setForeground(Color.WHITE);
	 secondFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	 secondFrame.setLocation(new Point(300,10));
	 secondFrame.setSize(new Dimension(800, 800));
	 secondFrame.setTitle("Aggregation Tool V2.0- " + getSimString());
	
	 JPanel mainPanel = new JPanel();
	  mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));

	  JPanel paintPanel = new JPanel();
	  JPanel textPanel = new JPanel();

	  mainPanel.add(paintPanel);
	  mainPanel.add(textPanel);
	  secondFrame.add(mainPanel);
	 
	 /* Text area for Log */
	 textAreaRunning = new JTextArea();
	 textAreaRunning.setEditable(false);
	 scrollAreaRunning = new JScrollPane(textAreaRunning); 
	 scrollAreaRunning.setPreferredSize(new Dimension (800,400));
	 textPanel.add(scrollAreaRunning);
	 
	 /*Drawing*/
	 netGUI = new NetworkGUI();    // Construct the drawing canvas
     netGUI.setPreferredSize(new Dimension (190,190));
     paintPanel.add(netGUI);
	 
	 /* ---- LAYOUT ---- */
	 firstFrame.setVisible(false);
	 firstFrame.dispose(); // destroy this frame
	 secondFrame.setLayout(new FlowLayout());
	 secondFrame.setVisible(true);
}


public void createAndShowBrowser() {
	JFileChooser fc = new JFileChooser();
	fc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
	int returnVal = fc.showOpenDialog(GraphicInterface.this);
	
	if (returnVal == JFileChooser.APPROVE_OPTION) {
		file = fc.getSelectedFile();
		System.out.println(file);
		button_settings.setEnabled(true);
	} 
}


public void actionPerformed(ActionEvent event) {
	if (event.getSource() == button_run) {
		setRun_control(true);
		createSecondGUI();
	}
			
	if (event.getSource() == button_browser) {
		createAndShowBrowser();
	}
			
	if (event.getSource() == button_settings) {
		//get the variables
		selected_solution= combo_solutions.getSelectedItem().toString(); 
		n_nodes=Integer.parseInt(number_nodes.getText());
		n_repts=Integer.parseInt(combo_repts.getSelectedItem().toString());
		simString=ID.getText();
				
		//generate the files
		SettingFilesGenerator genFiles = new SettingFilesGenerator();
		genFiles.setNetSize(n_nodes);
		genFiles.setPath(file.getAbsolutePath()+"/");
		genFiles.setDirname("AggregationTool/"+simString+"/");
		File resultsDir = new File(file.getAbsolutePath()+"/AggregationTool/"+simString+"/results/"); 
		resultsDir.mkdirs();
		genFiles.generator();
				
		GUIfinished=true;
		button_run.setEnabled(true);
	}
}

public void drawNode(float corX, float corY) {
	netGUI.drawCircle((int)corX, (int)corY);
}

public void drawEdge(float corX1, float corY1,float corX2, float corY2) {
	netGUI.drawLine((int)corX1, (int)corY1, (int)corX2, (int)(corY2));
}


}
	



	

 
  