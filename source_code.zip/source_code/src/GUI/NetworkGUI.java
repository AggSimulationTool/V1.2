package GUI;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Stroke;

import javax.swing.JPanel;

class NetworkGUI extends JPanel {
@Override



public void paintComponent(Graphics g) {
super.paintComponent(g);  
   
	setBackground(Color.white); 
}
    
public void drawCircle( int corX, int corY){
	Graphics g = super.getGraphics();
	g.setColor(Color.black);
	g.drawOval(corX, corY, 4, 4);
	g.setColor(Color.blue);
	g.fillOval(corX, corY, 4, 4);
}
    
public void drawLine( int corX1,  int corY1, int corX2, int corY2){
	Graphics g = super.getGraphics();
	int offset=2;//it is the radius size of the circle
    
	g.setColor(Color.black);
	g.drawLine(corX1+offset, corY1+offset, corX2+offset, corY2+offset);

}
    
}
