package code;

public class Actuator {
private String ID;
private String actuatorType;



public Actuator(String actuatorType) {
	this.actuatorType = actuatorType;
}

public String getID() {
	return ID;
}
public void setID(String iD) {
	ID = iD;
}
public String getActuatorType() {
	return actuatorType;
}
public void setActuatorType(String actuatorType) {
	this.actuatorType = actuatorType;
}


}
