package code;

import java.util.List;

public class DataRequest {
private float frequency;
private float delayTolerance;
private String ID;
private String aggFunction;
private String queryContent;
private String queriesType;
private List groupDevices;

public String getQueryContent() {
	return queryContent;
}


public void setQueryContent(String queryContent) {
	this.queryContent = queryContent;
}


public String getQueriesType() {
	return queriesType;
}


public void setQueryType(String queryType) {
	this.queriesType = queryType;
}


public DataRequest(float frequency, float delayTolerance, String iD,
		String aggFunction, String queryContent, String queryType) {
	this.frequency = frequency;
	this.delayTolerance = delayTolerance;
	this.ID = iD;
	this.aggFunction = aggFunction;
	this.queryContent = queryContent;
	this.queriesType = queryType;
}


public List getGroupDevices() {
	return groupDevices;
}

public void setGroupDevices(List groupDevices) {
	this.groupDevices = groupDevices;
}

public String getID() {
	return this.ID;
}
public void setID(String iD) {
	ID = iD;
}
public float getFrequency() {
	return frequency;
}
public void setFrequency(float frequency) {
	this.frequency = frequency;
}
public String getAggFunction() {
	return aggFunction;
}
public void setAggFunction(String aggFunction) {
	this.aggFunction = aggFunction;
}

public void setQuery(String query) {
	this.queryContent = query;
}
public float getDelayTolerance() {
	return delayTolerance;
}
public void setDelayTolerance(float delayTolerance) {
	this.delayTolerance = delayTolerance;
}
}
