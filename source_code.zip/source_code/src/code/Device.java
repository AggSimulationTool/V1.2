package code;

import java.util.ArrayList;
import java.util.List;

public class Device {

private String label;
private List<String> group = new ArrayList<String>();
private String state="Unvisited";
private float coordX;
private float coordY;
private float Tx_consumption;
private float Rx_consumption;
private float range;
private double InitialEnergy;
private List<Sensor> buildSensors = new ArrayList<Sensor>();
private List<Actuator> buildActuators = new ArrayList<Actuator>();
private float controlDataRate;

public float getControlDataRate() {
	return controlDataRate;
}

public void setControlDataRate(float controlDataRate) {
	this.controlDataRate = controlDataRate;
}

public List<Sensor> getBuildSensors() {
	return buildSensors;
}

public void addNewSensor(String dataType, float dataRate) {
	Sensor s = new Sensor(dataType, dataRate);
	this.buildSensors.add(s);
}

public void addNewActuator(String actuatorType) {
	Actuator a = new Actuator(actuatorType);
	this.buildActuators.add(a);
}


public List<Actuator> getBuildActuators() {
	return buildActuators;
}

public void setBuildActuators(List<Actuator> buildActuators) {
	this.buildActuators = buildActuators;
}

public String getLabel() {
	return label;
}

public void setLabel(String label) {
	this.label = label;
}

public List getGroup() {
	return group;
}

public String getFirstGroup(){
	String groupL= group.get(0);
	return groupL;
}

public void addGroup(String ID) {
	//System.out.println("\nNode "+ label + " belongs to group " + ID);
	this.group.add(ID);
}


public float getCoordX() {
	return coordX;
}

public float getCoordY() {
	return coordY;
}


public void setCoordX(float d) {
	this.coordX = d;
}

public void setCoordY(float coord) {
	this.coordY = coord;
}


public float getTx_consumption() {
	return Tx_consumption;
}

public float getRx_consumption() {
	return Rx_consumption;
}


public void setTx_consumption(float tx_consumption) {
	Tx_consumption = tx_consumption;
}

public void setRx_consumption(float rx_consumption) {
	Rx_consumption = rx_consumption;
}


public float getRange() {
	return range;
}


public void setRange(float range) {
	this.range = range;
}


public double getInitialEnergy() {
	return InitialEnergy;
}


public void setInitialEnergy(double initialEnergy) {
	InitialEnergy = initialEnergy;
}

public String getState() {
	return state;
}

public void setState(String state) {
	this.state = state;
}


	
	
}
