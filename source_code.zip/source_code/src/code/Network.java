package code;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.w3c.dom.*;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;

import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException; 

import java.lang.Integer;

public class Network {
	private NodeList settings;
	private List<Device> listDevices = new ArrayList<Device>();
	private boolean[][] linkMatrix;
	private List<DataRequest> listDataRequests = new ArrayList<DataRequest>();
	private List<Integer> orderVisit = new ArrayList<Integer>();
	private int currentTime=1; //Count the simulation time
	private List<String> communicatingGroups = new ArrayList(); //stores the ID of groups that will communicate in the current time slot
	private int gatewayIndex=0;
	private String gatewayLabelGroup="GW";
	
	
	public void clear(){
		this.communicatingGroups.clear();
		this.linkMatrix=null;
		this.listDataRequests.clear();
		this.listDevices.clear();
		this.orderVisit.clear();
		this.settings=null;
	}
	
	public void setTime(int time){
		this.currentTime=time;
	}
	
	
	public List getAllCommunicatingGroups(){
		return this.communicatingGroups;
	}
	
	
	public String getGatewayLabelGroup() {
		return gatewayLabelGroup;
	}



	public boolean[][] getLinkMatrix() {
		return linkMatrix;
	}


	public List<String> findDevicesOfGroup(String groupID){
		List <String> labelDevices = new ArrayList<String>();
		// Seek all the list of devices
		for(int i=0;i<this.listDevices.size();i++){
			for(int j=0;j<this.listDevices.get(i).getGroup().size();j++){
				if(this.listDevices.get(i).getGroup().get(j).equals(groupID)){
					//System.out.println("Group "+groupID+" Device "+this.listDevices.get(i).getLabel());
					labelDevices.add(this.listDevices.get(i).getLabel());
				}
			}
		}
		//It returns the list of devices labels belonging to the groupID
		return labelDevices;
	}
	
	public boolean fromSameGroup(int index1, int index2){
		String group1;
		String group2;

		group1 = this.getDevice(index1).getFirstGroup();  // Find the group of index1
		//System.out.println("Group of device "+ index1 + " is " + group1);
		group2 = this.getDevice(index2).getFirstGroup();  // Find the group of index2
		//System.out.println("Group of device "+ index2 + " is "+ group2);
		
		if(group1.equals(group2))
			return true;
		
		
		return false;
	}


	
	public float[] findCoordinates(String deviceLabel) {
		float [] coord=new float [2];
		for(int i=0;i<this.listDevices.size();i++){
			if(this.listDevices.get(i).getLabel().equals(deviceLabel))
			coord[0]=this.listDevices.get(i).getCoordX();
			coord[1]=this.listDevices.get(i).getCoordY();
		}
		return coord;
	}
	
	public Device getDevice(int index){
		return this.listDevices.get(index);
	}
	
	// Receives the label and returns the index
	public int findIndexDevice(String node){
		String label;
		int indexNode=0;
		for (int i=0;i<this.listDevices.size();i++){
			label=this.listDevices.get(i).getLabel();
			if(label.equals(node))
			indexNode=i;
		}
		return indexNode;
	}

	public String getCommunicatingGroups(int index) {
		return communicatingGroups.get(index);
	}

	public int getCurrentTime(){
		return this.currentTime;
	}
	
	public int getSizeCommunicatingGroups(){
		return this.communicatingGroups.size();
	}
	
	public int getGatewayIndex() {
		return gatewayIndex;
	}


	//Read the settings file and store
	public void readSettings(String fileName){
		try {
            DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
            Document doc = docBuilder.parse (new File(fileName));
            doc.getDocumentElement().normalize ();
            this.settings = doc.getElementsByTagName("*");
            System.out.println("Settings file read sucefully");

        }catch (SAXParseException err) {
        System.out.println("** Parsing error" + ", line " + err.getLineNumber () + ", uri " + err.getSystemId ());
        System.out.println(" " + err.getMessage ());

        }catch (SAXException e) {
        Exception x = e.getException ();
        ((x == null) ? e : x).printStackTrace ();

        }catch (Throwable t) {
        t.printStackTrace ();
        }

	}
	
	public String getSettings (String string){
		String strFound=null;
		for (int i = 0; i < this.settings.getLength(); i++) {
            Element element = (Element)this.settings.item(i);
            String nodeName = element.getNodeName();
            if (nodeName.equals(string)) 
            	strFound = element.getChildNodes().item(0).getNodeValue();
         }
		return strFound;
	}
	
	public void instanceDevices(){
		// Access the settings
		int nDevices = Integer.parseInt(this.getSettings("NumberOfDevices"));
		String sType = this.getSettings("Sensor");
		float sDataRate = Float.parseFloat(this.getSettings("SensorRate"));
		float cDataRate = Float.parseFloat(this.getSettings("controlDataRate"));
		double iEnergy = Float.parseFloat(this.getSettings("InitialEnergy"));
		float iEnergyVariation = Float.parseFloat(this.getSettings("InitialEnergyVariation"));
		
		// Instance and add the devices to the device list.
		for(int i=0; i<nDevices; i++){
			listDevices.add(new Device());
			listDevices.get(i).setControlDataRate(cDataRate);
			listDevices.get(i).setLabel(String.valueOf(i+1));
			listDevices.get(i).addNewSensor(sType, sDataRate);
			
			// ==== SETTING THE ENERGY ====
			if(this.getSettings("InitialEnergyDistribution").equals("Homogeneous"))
				listDevices.get(i).setInitialEnergy(iEnergy);
			else if (this.getSettings("InitialEnergyDistribution").equals("Heterogeneous")){
				// Min + (int)(Math.random() * ((Max - Min))). Min = iEnergy-iEnergyVariation; Max = iEnergy-iEnergyVariation
				listDevices.get(i).setInitialEnergy((iEnergy-iEnergyVariation) + (float)(Math.random() * ((iEnergyVariation+iEnergy)-(iEnergy-iEnergyVariation))));
				//System.out.println("Initial Energy: " + this.listDevices.get(i).getInitialEnergy());
			}
			// Set the initial energy of GW. By default GW is the node with index 0
			if(i==this.gatewayIndex)
				listDevices.get(i).setInitialEnergy(Float.MAX_VALUE);
			// ==== END OF SETTING ENERGY ====
		}
		
		
		//Allocates memory for linksMatrix
		this.linkMatrix = new boolean [this.listDevices.size()][this.listDevices.size()];
		System.out.println(this.listDevices.size() + " nodes created");
	}
	
	// Compute random coordinates for all nodes creating a connected graph
	public void setCoordinates(){
		int node=0;
		double angle=0;
		float r;
		int range = Integer.parseInt(this.getSettings("Range"));
		float minR = (float) (range*0.1);
		int nCol=0, nLin=0;
		double Hspace =0, Vspace = 0;
		double coordY=0;
		double coordX=0;
		
		// Verify the settings
		if (this.getSettings("GeographicDistribution").equals("Connected Random")) {	
			// Compute and set first node coordinate
			this.listDevices.get(0).setCoordX((float) (Math.random() * (100 + 1)));
			this.listDevices.get(0).setCoordY((float) (Math.random() * (100 + 1)));
			
			
			for(int i=1; i<this.listDevices.size();i++){
				//System.out.println("Computing coord of node: "+i);
				
				// select a random ref node
				node = (int) (((i-1)*0.5)+Math.round((Math.random() * ((i-1)-((i-1)*0.5)))));
				//System.out.println("Seleted ref node: "+(node));
				//System.out.println("Coord of ref node: "+ newDevices.get(node).getCoordX()+";"+newDevices.get(node).getCoordY());
				
				// Compute an angle
				angle = (Math.random()*(360));
				//System.out.println("Angulo: "+angle);
				
				// Compute a distance from ref node. Max distance is range
				r =  minR+(float)(Math.random() * (range-minR));
				//System.out.println("Distance: "+r);
				
				// Compute and set x and y-axis points
				this.listDevices.get(i).setCoordX((float) (r*Math.sin(Math.toRadians(angle))+this.listDevices.get(node).getCoordX()));
				this.listDevices.get(i).setCoordY((float) (r*Math.cos(Math.toRadians(angle))+this.listDevices.get(node).getCoordY()));
								
				
				//System.out.println("New Coord: "+this.newDevices.get(i).getCoordX()+";"+this.newDevices.get(i).getCoordY());
			}
			System.out.println("Coordinates created randomly, forming a connected graph");
		}
		
		// Verify the settings
		else if (this.getSettings("GeographicDistribution").equals("Grid1")) {	
			//find the number of columns. It is the root square of the total nodes
			nCol =(int) Math.sqrt((double) this.listDevices.size());
			nLin=(int) this.listDevices.size()/nCol;
			float nodesDistance= Float.valueOf(this.getSettings("nodesDistance"));
			//
			//Increment nLin to include all nodes
			while(nLin*nCol<this.listDevices.size()){
				nLin++;
			}
			
			
			System.out.println("Col "+nCol+" lin "+nLin);
			
			//Horizontal space. 0.85 is sen of 45
			Hspace = 10;
			//double Hspace = 0.85*(0.7*range);
			
			// Vertical space. 0.52 is the cos of 45
			Vspace = 10;
			//double Vspace = 0.52*(0.7*range);

			
			System.out.println("H "+Hspace+" V "+Vspace);

			
			int i=1;//not include the Gateway

			coordY=0;
			coordX=0;
			//System.out.println("nLin "+nLin+" nCol "+nCol);
			for(int j=0;j<nLin;j++){
				for(int k=0;k<nCol;k++){
						if(i< this.listDevices.size()){
						//System.out.println("I "+ i + " K "+ k + " j " +j);
						this.listDevices.get(i).setCoordX((float) coordX);
						this.listDevices.get(i).setCoordY((float) coordY);
					
						coordX=coordX+Vspace; 						//update
						System.out.println("Device "+this.listDevices.get(i).getLabel()+" X: "+this.listDevices.get(i).getCoordX()+ " Y: "+this.listDevices.get(i).getCoordY());
						i++;
						}
					}
				coordY=coordY+Hspace;
				coordX=0;
				}
		
			}
		
		else if (this.getSettings("GeographicDistribution").equals("Grid2")) {	
			//find the number of columns. It is the root square of the total nodes
			nLin	=(int) Math.sqrt((double) this.listDevices.size());
			nCol=(int) this.listDevices.size()/nLin;
			float nodesDistance= Float.valueOf(this.getSettings("nodesDistance"));
			//
			//Increment nLin to include all nodes
			while(nLin*nCol<this.listDevices.size()){
				nLin++;
			}
			
			
			System.out.println("Col "+nCol+" lin "+nLin);
			
			//Horizontal space. 0.85 is sen of 45
			Hspace = 20;
			//double Hspace = 0.85*(0.7*range);
			
			// Vertical space. 0.52 is the cos of 45
			Vspace = 20;
			//double Vspace = 0.52*(0.7*range);

			
			System.out.println("H "+Hspace+" V "+Vspace);

			
			int i=1;//not include the Gateway

			coordY=0;
			coordX=0;
			//System.out.println("nLin "+nLin+" nCol "+nCol);
			for(int j=0;j<nLin;j++){
				for(int k=0;k<nCol;k++){
						if(i< this.listDevices.size()){
						//System.out.println("I "+ i + " K "+ k + " j " +j);
						this.listDevices.get(i).setCoordX((float) coordX);
						this.listDevices.get(i).setCoordY((float) coordY);
					
						coordX=coordX+Vspace; 						//update
						System.out.println("Device "+this.listDevices.get(i).getLabel()+" X: "+this.listDevices.get(i).getCoordX()+ " Y: "+this.listDevices.get(i).getCoordY());
						i++;
						}
					}
				coordY=coordY+Hspace;
				coordX=0;
				}
		
			}
			
			if (this.getSettings("GWlocation").equals("Center")) {
				int center;
				center=((int) this.listDevices.size()/2);
				//center = ((int) coordY/2);
				
				System.out.println("Center "+center+ " H "+Hspace);
				
				// The gateway in the center
				float coordx=(float) ((nCol/2 * Hspace) - (Hspace/2)) ;
				float coordy=(float) ((nLin/2 * Vspace) - (Vspace/2)) ;
				this.listDevices.get(0).setCoordX (coordx);
				this.listDevices.get(0).setCoordY(coordy) ;
				System.out.println("Center: "+this.listDevices.get(0).getCoordX()+" , "+this.listDevices.get(0).getCoordY() );

			}
			
			else{
				System.out.println("Geographic Distribution not well specifyed");
				System.exit(0);
			}
			
			System.out.println("Grid coordinates created, forming a connected graph");
	}
	
	public void setLinks(){
		for(int i=0; i<this.listDevices.size();i++){
			for(int j=0; j<this.listDevices.size();j++){
				if((i!=j)&(this.neighbors(i, j)==true)){
					// System.out.println(i+" "+j+ " Yes");
					this.linkMatrix[i][j]=true;
				}
				else {
					// System.out.println(i+" "+j+ " No");
					this.linkMatrix[i][j]=false;
				}
			}
		}
		System.out.println("Links between neighbors nodes created");
	}
	
	//Test if two nodes are neighbors
	public boolean neighbors(int node1, int node2){
		int range = Integer.parseInt(this.getSettings("Range"));
		float xDiff, yDiff;
	
		xDiff=this.listDevices.get(node1).getCoordX() - this.listDevices.get(node2).getCoordX();
		yDiff=this.listDevices.get(node1).getCoordY() - this.listDevices.get(node2).getCoordY();
		//System.out.println(Math.pow(xDiff, 2)+Math.pow(yDiff, 2));
		
		if((Math.sqrt(Math.pow(xDiff, 2) + Math.pow(yDiff, 2)))<=range)
			return true;
		else
			return false;
	}
	
	// Create the queries specified in the settings file
	public void instanceDataRequest(){
		String ID, content, type, aggF;
		float freq, delayTol;
		// Access the settings to know how many queries should be created
		int nDataRequests = Integer.parseInt(this.getSettings("NumberDataRequests"));
		System.out.println(nDataRequests);
		
		// All the queries are the same type
		type=this.getSettings("QueriesType");
		System.out.println(type);
		
		for (int i=1; i<nDataRequests+1;i++){
			//System.out.println("i "+i);
			
			ID=this.getSettings("DR"+i+"-ID");
			//System.out.println(ID);
			
			content=this.getSettings("DR"+i+"-QueryContent");
			//System.out.println(content);
			
			aggF=this.getSettings("DR"+i+"-AggFunction");
			//System.out.println(aggF);
			

			if(this.getSettings("DRFrequency").equals("random")){
				int minF = 1;
				int maxF = 1;
				freq = minF + (int)(Math.random() * ((maxF - minF) + 1));
				System.out.print("\n Frequency"+ freq );
			}
			else{
				freq=Float.parseFloat(this.getSettings("DR"+i+"-Frequency"));
				//System.out.println(freq);
			}
			
			delayTol=Float.parseFloat(this.getSettings("DR"+i+"-DelayTolerance"));
			this.listDataRequests.add(new DataRequest(freq, delayTol, ID, aggF, content, type));
		}
		System.out.println("\nData Requests created: "+this.listDataRequests.size());
	}
	
	//Find the group of nodes that should communicate data periodically. Solving the query
	public void solveQueries(){ 
		String subsetID;
		int subsetSize;
		String drMode = this.getSettings("DataRequestOverlapping");
		String groupSelectionAlgorithm = this.getSettings("GroupSelection");
		int numberOfGroups;
		int indexOrder=0;
		int sqrtSubset=0;
		int Lsize=0, Csize=0;
		List <Integer> divisors = new ArrayList<Integer>();
		// This query specifies the number of nodes that will response the query 
					if(this.listDataRequests.get(0).getQueriesType().equals("Subset")){
						if(drMode.equals("Minimize")){
							if(groupSelectionAlgorithm.equals("DFS")){
								// System.out.println("DFS order:");
								//DFS begins with 0, which is the GW
								this.DFS(this.gatewayIndex);
								this.removeGWfromOrderVisit();//remove os GW da lista
								numberOfGroups = Integer.parseInt(this.getSettings("NumberDataRequests"));
								for (int i=0; i<numberOfGroups;i++){
									//Access the data request content
									subsetSize=Integer.parseInt(this.listDataRequests.get(i).getQueryContent());
									subsetID=this.listDataRequests.get(i).getID();
									 System.out.println("\nGroup " + subsetID);
									for (int j=0;j<subsetSize;j++){
										 //System.out.print(this.listDevices.get(this.orderVisit.get(indexOrder)).getLabel()+" ");
										this.listDevices.get(this.orderVisit.get(indexOrder)).addGroup(subsetID);
										indexOrder++;
										// should be -1, because the last shouldn't be member of any group since it is the GW 
										if(indexOrder==this.orderVisit.size())
											indexOrder=0;
									}
								}
							}
							else if(groupSelectionAlgorithm.equals("Square")){
								indexOrder=1; // gateway shouldn'd belong to any group
								numberOfGroups = Integer.parseInt(this.getSettings("NumberDataRequests"));
								for (int i=0; i<numberOfGroups;i++){
									//Access the data request content
									subsetSize=Integer.parseInt(this.listDataRequests.get(i).getQueryContent());
									subsetID=this.listDataRequests.get(i).getID();
									 System.out.println("\nGroup " + subsetID);
									 
									 
									 for (int k=0;k<subsetSize;k++){
										 System.out.print(this.listDevices.get(indexOrder).getLabel()+" ");
										 this.listDevices.get(indexOrder).addGroup(subsetID);
										 if(indexOrder==this.listDevices.size())// In case of overlapping
											 indexOrder=0;
										 indexOrder++;
									}
								}
							}
						}
						else
							System.out.println("Data Request Overlapping not implemented");
					}
					else{ 
						System.out.println("Query type not implemented");
					}
	}
	
	public void DFS(int node){
		int j=0;
		this.listDevices.get(node).setState("Inprogress");
		//j: neighbors
			for (j=0;j<this.listDevices.size();j++){
				if((this.linkMatrix[node][j]==true)&&(this.listDevices.get(j).getState().equals("Unvisited"))){
					this.DFS(j);
				}
		}

			this.orderVisit.add(node);
			this.listDevices.get(node).setState("Visited");
			 //System.out.println(node);
	}
	
	public void removeGWfromOrderVisit(){
		for (int i=0;i<this.orderVisit.size();i++){
			if(this.orderVisit.get(i)==this.gatewayIndex){
				
				this.orderVisit.remove(this.orderVisit.get(i));
			}
		}
	}
	
	public void printMatrix(){
		System.out.println("Link Matrix:");
		for (int i=0;i<this.listDevices.size();i++){
			System.out.println();
			for (int j=0;j<this.listDevices.size();j++){
				if(this.linkMatrix[i][j]==false)
					System.out.print(0+" ");
				else
					System.out.print(1+" ");
			}
		}
		System.out.println("\n");
	}
	
		// Find the groups that will communicate in that time slot
		public void findCommunicatingGroups(){
			int freInactiveNodes=Integer.parseInt(this.getSettings("InactiveNodesFreq"));
			for (int i=0;i<this.listDataRequests.size();i++){
				if(((this.currentTime-1) % this.listDataRequests.get(i).getFrequency())==0){
					this.communicatingGroups.add(this.listDataRequests.get(i).getID());
					//System.out.println("\n Current Time: " + this.currentTime + " group: "+this.listDataRequests.get(i).getID());
				}
			}			
			if((this.findInactiveNode())&&(((this.currentTime-1) % freInactiveNodes)==0)){
				this.communicatingGroups.add("Inactive");
			}
			
			//Each GW is a group always active
			String gatewayGroupID=this.gatewayLabelGroup;
			this.listDevices.get(this.gatewayIndex).addGroup(gatewayGroupID);
			this.communicatingGroups.add(gatewayGroupID);
		}
		
		public void setInactiveGroup(){
		System.out.println("\nGroup Inactive ");
			for (int i=0;i<this.listDevices.size();i++){
				if (this.listDevices.get(i).getGroup().isEmpty() && i!=this.gatewayIndex){
					this.listDevices.get(i).addGroup("Inactive");
					 System.out.print(this.listDevices.get(i).getLabel() + " ");
				}
			}
		}
		
		
		public boolean findInactiveNode(){
			for (int i=0;i<this.listDevices.size();i++){
				for (int j=0;j<this.listDevices.get(i).getGroup().size();j++){
					if (this.listDevices.get(i).getGroup().get(j).equals("Inactive"))
						return true;
				}
			}
					return false;
		}
		
		
		public void clearCommunicatingGroups(){
			this.communicatingGroups.clear();
		}
		
		public void incrementTime(){
			this.currentTime++;	
		}
		
		public float findDistance(int n1Index, int n2Index){
			float distance;
			float n1X, n1Y, n2X, n2Y;
			
			// get the coordenates
			n1X=this.getDevice(n1Index).getCoordX();
			n1Y=this.getDevice(n1Index).getCoordY();
			n2X=this.getDevice(n2Index).getCoordX();
			n2Y=this.getDevice(n2Index).getCoordY();
			// compute the distance
			distance=(float) Math.sqrt(Math.pow((n1X-n2X),2) + Math.pow((n1Y-n2Y),2));
			
			return distance;
		}
		
		
	
}