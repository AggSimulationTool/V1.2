package code;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;

import GUI.GraphicInterface;
import solutions.Damig_MaximumEnergy.*;
import solutions.Damig_MinimumSpanningTree.*;
import solutions.Damig_ShortestPathTree.*;
import solutions.NoInterGroupAggregation.*;
import solutions.ttama.TTAMA;

public class Run {
	/*ATTRIBUTES*/
	static Network N1 = new Network();
	static Thread guiTread = new Thread();
	static String path; 
	static String pathFiles;
	static String pathResults;
	static GraphicInterface myGUI;
	static int netSize=101;//
	
	/*SOLUTIONS*/
	static TTAMA ttama;
	static DAMiG_MST damigMST;	
	static DAMiG_MaxEnergy damigMaxEnergy;	
	static EERS eers;
	static DAMiG_SPT damigSPT;

	
	public static void main(String[] args) {


		List<String> filename =	 new ArrayList();
		List<String> line = new ArrayList();
		String computerLabel="-x";

		String executionOrder="increase";


		// Performance variables		
		int numberOfSolutions=5; // damigMST, EESR, DamigMaxEnergy, Damig-spt and TTAMA
		int numberOfVariables=3; 
		int[] rounds = new int[numberOfSolutions];
		double[] avgResidualEnergy = new double[numberOfSolutions];
		double[] avgIntraEnergy = new double[numberOfSolutions];
		double[] avgInterEnergy= new double[numberOfSolutions];
		double[] residualEnergy0 = new double[netSize];
		double[] residualEnergy1 = new double[netSize];
		double[] residualEnergy2 = new double[netSize];
		double[] residualEnergy3 = new double[netSize];
		double[] residualEnergy4 = new double[netSize];

			
		//Damig_LinkCost1
		int indexDamigMST = 0;
		
		//No Inter Group Agg
		int indexEERS= 1;
		
		//Dodag
		int indexDamigMaxEnergy = 2;
		
		//SPT
		int indexDamigSpt = 3;
		
		//TTAMA
		int indexTtama = 4;
				
		
		// EDIT THIS
		path = "/Users/andreriker/Documents/Dropbox/EclipseWorkspace/SimulatonTool-Set2015/";
		pathFiles = path+"settingsFiles/" +Integer.valueOf(netSize-1)+"-nodes/";
		pathResults = path + "/results/";		
		
		// ##########################################################
		// ####################### GUI ##############################
		// ##########################################################
		GUIinterface();
		
		// ##########################################################
		// ####################### ARGS ##############################
		// ##########################################################
		// Get the args values from the command line
		for (int i=0; i<args.length;i++){
			if(i==0) // The first parameter is the path
				path = args[i]+"/SimulationTool-Set2015/";
			if(i==1) // Second parameter is the network size
				netSize = Integer.valueOf(args[i]);
			if(i==2) // Third  parameter is the pc label
				computerLabel = "-"+args[i];
			if(i==3) // Fourth  parameter is the order of execution, which can increase or decrease
				executionOrder = args[i];
		}

		// ##########################################################
		// ####################### FILES ##############################
		// ##########################################################

		// Find the group sizes. 1, 2, 4, 8, 16, 32
		 for(int i=1;i<netSize;i++){ //Default 
			if((netSize-1) % i == 0 &&(i<=netSize-1))
				filename.add(i+"Groups.xml"); 
		}
		
        String fileCommRounds = pathResults+"Lifetime.txt";
        String fileResidualEnergy = pathResults+"ResidualEnergy.txt";
        String fileIntraEnergy = pathResults+"IntraEnergy.txt";
        String fileInterEnergy = pathResults+"InterEnergy.txt"; ;

        
        // ---------- File 1: ComRounds  ----------
	       BufferedWriter wr = null;
	        try {
	            FileWriter f = new FileWriter(fileCommRounds, true);
	            wr = new BufferedWriter(f);
	        } 	        
	        catch (Exception e) {e.printStackTrace();} 
	        try {wr.close();} 
	        catch (Exception e) {}
	        
	        
			// ---------- File 2: ResidualEnergy  ----------
	       BufferedWriter wr2 = null;
	        try {
	            FileWriter f2= new FileWriter(fileResidualEnergy , true);
	            wr2 = new BufferedWriter(f2);
	        } 	        
	        catch (Exception e) {e.printStackTrace();} 
	        try {wr2.close();} 
	        catch (Exception e) {}
		        
	        
			// ---------- File 3: intraEnergy  ----------
		     BufferedWriter wr3 = null;
		      try {
		            FileWriter f3= new FileWriter(fileIntraEnergy , true);
		            wr3 = new BufferedWriter(f3);
		      } 		        
		        catch (Exception e) {e.printStackTrace();} 
		        try {wr3.close();} 
		        catch (Exception e) {}
			        
		        
				//  ---------- File 4:  interEnergy  ----------
		       BufferedWriter wr4 = null;
		        try {
		            FileWriter f4= new FileWriter(fileInterEnergy , true);
		            wr4 = new BufferedWriter(f4);
		        } 
		        catch (Exception e) {e.printStackTrace();} 
		        try {wr4.close();} 
		        catch (Exception e) {}

			// ###############################################################
	        // ###################### SIMULATION SETTINGS ##############################
			// ###############################################################
	        int maxRepetition = 2; // Repetition of each group settings			
			int iterator=0;
			if(executionOrder.equals("decrease"))
				iterator=filename.size()-1;
			
			
			myGUI.writeToRunningFrame("========================================");
			myGUI.writeToRunningFrame("                 ------- SIMULATIONS STARTED -------");
			myGUI.writeToRunningFrame("========================================\n\n");
		// This FOR controls the number of repetitions
		for(int i=0;i<filename.size();i++){
			for(int repetition=0;repetition<maxRepetition;repetition++){
				
				N1.clear();
				N1.readSettings(pathFiles+filename.get(iterator));
				N1.instanceDevices();
				N1.setCoordinates();
				N1.setLinks();
				//N1.printMatrix();
				System.out.println("Instance Data Request");
				N1.instanceDataRequest();
				N1.solveQueries();
				N1.setInactiveGroup();
				

				myGUI.writeToRunningFrame("= Input Settings "+filename.get(iterator)+" # "+(repetition+1));
				plotNetworkGUI();

	
				// #####################################################################
				// ====================== OBJECTS  ================ 
				// #####################################################################

				//Instantiate the solutions
				ttama = new solutions.ttama.TTAMA();
				damigMST = new DAMiG_MST();
				damigMaxEnergy = new DAMiG_MaxEnergy();	
				eers = new EERS();
				damigSPT = new DAMiG_SPT();
				
				//Set the network objects
				ttama.setNetwork(N1);
				damigMST.setNetwork(N1);
				damigMaxEnergy.setNetwork(N1);
				eers.setNetwork(N1);
				damigSPT.setNetwork(N1);
				
				// ###############################################################
				// ============= RUN SIMULATION AND GET RESULTS =====================

				System.out.print("\n\n\n ================== DAMIG-MST==================  ");
				myGUI.writeToRunningFrame("== Solution damigMST");
				damigMST.simulation();
				rounds[indexDamigMST]=damigMST.getCommunicationRounds();
				avgResidualEnergy[indexDamigMST]=damigMST.getAvgResidualEnergy();
				avgIntraEnergy[indexDamigMST] = damigMST.getSumIntraEnergy()/(netSize-1);
				avgInterEnergy[indexDamigMST] = damigMST.getSumInterEnergy()/(netSize-1);
				for(int k=0;k<netSize;k++){
					residualEnergy0[k] = damigMST.getResidualEnergy(k);
				}
				
				System.out.print("\n\n\n ================== EERS ==================  ");
				myGUI.writeToRunningFrame("== Solution EERS");
				eers.simulation();
				rounds[indexEERS] =  eers.getCommunicationRounds();
				avgResidualEnergy[indexEERS] = eers.getAvgResidualEnergy();
				avgIntraEnergy[indexEERS] = eers.getSumIntraEnergy()/(netSize-1);
				avgInterEnergy[indexEERS] = eers.getSumInterEnergy()/(netSize-1);
				for(int k=0;k<netSize;k++){
					residualEnergy2[k] = eers.getResidualEnergy(k);
				}
				
				System.out.print("\n\n\n ==================  DAMiG-MaxEnergy ==================  ");
				myGUI.writeToRunningFrame("== Solution damigMAX Energy");
				damigMaxEnergy.simulation();
				rounds[indexDamigMaxEnergy]=damigMaxEnergy.getCommunicationRounds();
				avgResidualEnergy[indexDamigMaxEnergy]=damigMaxEnergy.getAvgResidualEnergy();
				avgIntraEnergy[indexDamigMaxEnergy] = damigMaxEnergy.getSumIntraEnergy()/(netSize-1);
				avgInterEnergy[indexDamigMaxEnergy] = damigMaxEnergy.getSumInterEnergy()/(netSize-1);
				for(int k=0;k<netSize;k++){
					residualEnergy1[k] = damigMaxEnergy.getResidualEnergy(k);
				}

				System.out.print("\n\n\n ================== DAMiG-SPT ==================  ");
				myGUI.writeToRunningFrame("== Solution damigSPT");
				damigSPT.simulation();
				rounds[indexDamigSpt] =  damigSPT.getCommunicationRounds();
				avgResidualEnergy[indexDamigSpt] = damigSPT.getAvgResidualEnergy();
				avgIntraEnergy[indexDamigSpt] = damigSPT.getSumIntraEnergy()/(netSize-1);
				avgInterEnergy[indexDamigSpt] = damigSPT.getSumInterEnergy()/(netSize-1);
				for(int k=0;k<netSize;k++){
					residualEnergy3[k] = damigSPT.getResidualEnergy(k);
				}

				
				System.out.print("\n\n\n ================== TTAMA ==================  ");
				myGUI.writeToRunningFrame("== Solution TTAMA");
				ttama.simulation();
				rounds[indexTtama]=ttama.getCommunicationRounds();
				avgResidualEnergy[indexTtama]=ttama.getAvgResidualEnergy();
				avgIntraEnergy[indexTtama] = ttama.getSumIntraEnergy()/(netSize-1);
				avgInterEnergy[indexTtama] = ttama.getSumInterEnergy()/(netSize-1);
				for(int k=0;k<netSize;k++){
					residualEnergy4[k] = ttama.getResidualEnergy(k);
				}
			
				
				//###################################################################
				//===================== WRITE THE RESULTS IN THE FILES =======================
				if(rounds[indexDamigMST] > 1 || rounds[indexDamigMaxEnergy] > 1 ||rounds[indexEERS] > 1 || rounds[indexDamigSpt] > 1  || rounds[indexTtama] > 1){
					
						line.add(rounds[indexDamigMST] + ";" +rounds[indexEERS]+";" +rounds[indexDamigMaxEnergy]+";" +rounds[indexDamigSpt]+ ";" +rounds[indexTtama]);				
						line.add(avgResidualEnergy[indexDamigMST] + ";" +avgResidualEnergy[indexEERS]+";"+avgResidualEnergy[indexDamigMaxEnergy]+";"+avgResidualEnergy[indexDamigSpt]  + ";" +avgResidualEnergy[indexTtama]);    
						line.add(avgIntraEnergy[indexDamigMST]+";" +avgIntraEnergy[indexEERS]+";"+avgIntraEnergy[indexDamigMaxEnergy]+";"+avgIntraEnergy[indexDamigSpt]+ ";"+avgIntraEnergy[indexTtama]);			
						line.add(avgInterEnergy[indexDamigMST]+";" +avgInterEnergy[indexEERS]+";"+avgInterEnergy[indexDamigMaxEnergy]+";"+avgInterEnergy[indexDamigSpt] +";"+avgInterEnergy[indexTtama]);				
					
					// Write the Communication Rounds
					try {
					wr = new BufferedWriter(new FileWriter(fileCommRounds, true));
					wr.write(filename.get(iterator)+"\n");
					wr.write(rounds[indexDamigMST]+";");
					wr.write(rounds[indexEERS]+";");
					wr.write(rounds[indexDamigMaxEnergy]+";");
					wr.write(rounds[indexDamigSpt]+";");
					wr.write(rounds[indexTtama]+"\n");
					wr.close();
					line.clear();
		    		}
					catch (Exception e) {e.printStackTrace();}

					// Write the Residual Energy
					try {
					wr2 = new BufferedWriter(new FileWriter(fileResidualEnergy, true));
					wr2.write(filename.get(iterator)+"\n");
						for(int k=0;k<netSize;k++){
							wr2.write(Double.toString(residualEnergy0[k])+";"); // Damig Mst
							wr2.write(Double.toString(residualEnergy1[k])+";"); // Damig MaxEnergy
							wr2.write(Double.toString(residualEnergy2[k])+";"); // EERS
							wr2.write(Double.toString(residualEnergy3[k])+";"); // Damig Spt
							wr2.write(Double.toString(residualEnergy4[k])+"\n"); // TTAMA
						}
						wr2.close();
		    		}
					catch (Exception e) {e.printStackTrace();}
				
					// Write the Intra Energy Consumed
					try {
					wr3 = new BufferedWriter(new FileWriter(fileIntraEnergy, true));
					wr3.write(filename.get(iterator)+"\n");
							wr3.write(Double.toString(avgIntraEnergy[indexDamigMST])+";");
							wr3.write(Double.toString(avgIntraEnergy[indexEERS])+";");
							wr3.write(Double.toString(avgIntraEnergy[indexDamigMaxEnergy])+";");
							wr3.write(Double.toString(avgIntraEnergy[indexDamigSpt])+";");
							wr3.write(Double.toString(avgIntraEnergy[indexTtama])+"\n");
						wr3.close();
		    		}
					catch (Exception e) {e.printStackTrace();}
					
					// Write the Inter Energy Consumed
					try {
					wr4 = new BufferedWriter(new FileWriter(fileInterEnergy, true));
					wr4.write(filename.get(iterator)+"\n");
							wr4.write(Double.toString(avgInterEnergy[indexDamigMST])+";");
							wr4.write(Double.toString(avgInterEnergy[indexEERS])+";");
							wr4.write(Double.toString(avgInterEnergy[indexDamigMaxEnergy])+";");
							wr4.write(Double.toString(avgInterEnergy[indexDamigSpt])+";");
							wr4.write(Double.toString(avgInterEnergy[indexTtama])+"\n");
						wr4.close();
		    		}
					catch (Exception e) {e.printStackTrace();}
				}
				myGUI.writeToRunningFrame("");
		}//end for

			
			if(executionOrder.endsWith("decrease"))
				iterator--;
			else
				iterator++;
		}

	

    try {wr.close();} 
    catch (Exception e) {}

    System.out.print("\n\n\n\n\n========================================");
	System.out.print("\n------- SIMULATIONS ENDED -------");
    System.out.print("\n========================================");
    
	myGUI.writeToRunningFrame("\n\n========================================");
	myGUI.writeToRunningFrame("                 ------- SIMULATIONS ENDED -------");
	myGUI.writeToRunningFrame("========================================");
}
	
	
private static void GUIinterface() {
	myGUI = new GraphicInterface();
	myGUI.createFirstGUI();
	guiTread.start();
    synchronized(guiTread){
        try{
    		while(myGUI.getRun_control()==false) {
    			guiTread.wait(1000);
    		}
        }catch(InterruptedException e){
            e.printStackTrace();
        }
    }
    
    // Dont get this info if the GUI is not created
    if(myGUI.isCreated()) {
    		netSize=myGUI.getNsize();
    		path = myGUI.getPath();
    		pathFiles = path+"settingFiles/";
    		pathResults = path + "/results/";	
    }

}


private static void plotNetworkGUI() {
	/*plot the network*/
	for(int n=0;n<netSize;n++) {
		myGUI.drawNode(N1.getDevice(n).getCoordX(),N1.getDevice(n).getCoordY());
	}
	
	for(int n1=0;n1<netSize;n1++) {
		for(int n2=0;n2<netSize;n2++) {
			if(N1.getLinkMatrix()[n1][n2]) {
				//System.out.println("Node "+n1+ "(" + N1.getDevice(n1).getCoordX() + "," + N1.getDevice(n1).getCoordX() +  ") is nbg of " + n2 + "(" + N1.getDevice(n2).getCoordX() + "," + N1.getDevice(n2).getCoordX() +")");
				myGUI.drawEdge(N1.getDevice(n1).getCoordX(),N1.getDevice(n1).getCoordY(),N1.getDevice(n2).getCoordX(),N1.getDevice(n2).getCoordY());
			}
		}
	}
}
	

}
