package code;

public class Sensor {
private String ID;
private String dataType;
private float dataRate;


public Sensor(String dataType, float dataRate) {
	this.dataType = dataType;
	this.dataRate = dataRate;
}

public String getID() {
	return ID;
}
public void setID(String iD) {
	ID = iD;
}
public String getDataType() {
	return dataType;
}
public void setDataType(String dataType) {
	this.dataType = dataType;
}
public float getDataRate() {
	return dataRate;
}
public void setDataRate(float dataRate) {
	this.dataRate = dataRate;
}
}
