package filesGeneration;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;

	
public class SettingFilesGenerator {
	List<String> groupLabels = new ArrayList();
	int netSize=101;//1 is the GW
	String path = "/Users/user/Documents/Dropbox/EclipseWorkspace/M2MSimulatorV1.2/settingsFiles/"; // Default path
	String randomFreq="random";
	String Dirname;

	public void setDirname(String dir) {
		Dirname=dir;
	}
	
	
	public int getNetSize() {
		return netSize;
	}


	public void setNetSize(int netSize) {
		this.netSize = netSize;
	}


	public String getPath() {
		return path;
	}


	public void setPath(String path) {
		this.path = path;
	}


	public String getRandomFreq() {
		return randomFreq;
	}


	public void setRandomFreq(String randomFreq) {
		this.randomFreq = randomFreq;
	}
	
	
public void generator(){

	List<Integer> nDR= new ArrayList();
	
	// Find the divisors of the network size. Each divisor is an Data-request, which is stored in nDR
	for(int i=1;i<netSize;i++){
		if((netSize-1) % i == 0)
			nDR.add(i); 
	}
	

	
	//Call the class that creates the files
	SettingFilesGenerator filesettings = new SettingFilesGenerator();
	filesettings.generateGroupLabels();
	
	for(int i=0;i<nDR.size();i++){
			filesettings.createFile(nDR.get(i),netSize, Dirname, path, randomFreq);
		}
}
	
		
private void createFile(int nDR, int nNodes, String Dirname, String path, String randomFreq){
	//String path=System.getProperty("user.dir")+"/settingsFiles/";
	//String path="/Users/user/Documents/Dropbox/EclipseWorkspace/M2MSimulatorV1.2/settingsFiles/";
	String posStr = ".xml";
	
	String nl = "\n";
	BufferedWriter writer = null;
	String fileName = nDR+"Groups";
	
	
	
	path=path+Dirname+"settingFiles/";
	
	
	File theDir = new File(path);

  // if the directory does not exist, create it
if (!theDir.exists()) {
	System.out.println("creating directory: " + path);
	boolean result = theDir.mkdirs();  

 if(result) {    
   System.out.println("DIR created");  
     }
  }


try {
		
		File myFile = new File(fileName);
	
		FileWriter f = new FileWriter(path+fileName+posStr);
	
		writer = new BufferedWriter(f);
		
		
		
		writer.write("<simulation>"+nl);
	
	
	writer.write("<Devices>"+nl);
	writer.write("<!-- Int  -->"+nl);
	writer.write("<NumberOfDevices>"+nNodes+"</NumberOfDevices>"+nl);
		
	writer.write("<!--  Standard Unit  -->"+nl);
	writer.write("<Range>30</Range>"+nl);
	
		
	writer.write("<!--  Heterogeneous or Homogeneous  -->"+nl);
	writer.write("<InitialEnergyDistribution>Homogeneous</InitialEnergyDistribution>"+nl);
		
	writer.write("<!-- Amount of energy. Joules -->"+nl);
	writer.write("<InitialEnergy>0.01</InitialEnergy>"+nl);
		
	writer.write("<!-- The initialEnergy value will vary + and - the initialEnergyVariation-->"+nl);
	writer.write("<InitialEnergyVariation>0</InitialEnergyVariation>"+nl);
		
	writer.write("<!-- Connected Random, Grid  -->"+nl);
	writer.write("<GeographicDistribution>Grid2</GeographicDistribution>"+nl);
	
	writer.write("<!--  Distance between nodes -->"+nl);
	writer.write("<nodesDistance>20</nodesDistance>"+nl);
	
	
	writer.write("<!-- In this version all devices will be equipped with 1 same sensor -->"+nl);
	writer.write("<!-- Temperature, Humidity, Gas, Water, Energy. -->"+nl);
	writer.write("<Sensor>Temperature</Sensor>"+nl);
		
	writer.write("<!-- kbps -->"+nl);
	writer.write("<SensorRate>20</SensorRate>"+nl);
		
	writer.write("</Devices>"+nl);
	
	writer.write("<Gateway>"+nl);
	writer.write("<!-- This program is not designed to have multiple Gateways. The Gateway is by default the device with index 0.  -->"+nl);
	writer.write("<!-- Int. This version support only 1  -->"+nl);
	writer.write("<NumberOfGW>1</NumberOfGW>"+nl);
	writer.write("<!-- GW location: Corner (default) or center  -->"+nl);
	writer.write("<GWlocation>Center</GWlocation>"+nl);
	writer.write("</Gateway>"+nl);
	
	
	writer.write("<MultipleDataRequests>"+nl);
	writer.write("<!-- The number of DR that will be created -->"+nl);
	writer.write("<NumberDataRequests>"+nDR+"</NumberDataRequests>"+nl);
		
	writer.write("<!--  Subset selects randomly an set according to the size specified in the content -->"+nl);
	writer.write("<!--  Next versions will implement ID, Data Type, Geographic, Energy Level and Random  -->"+nl);
	writer.write("<QueriesType>Subset</QueriesType>"+nl);
	
	writer.write("<!--  Group Formation algorithm. DFS (Deepth First Search) or square. Square is indicated for grid scenarios. -->"+nl);
	writer.write("<GroupSelection>Square</GroupSelection>"+nl);
		
	writer.write("<!-- Interaction mode between the DRs. This version implements minimize, but max can be implemented -->"+nl);
	writer.write("<DataRequestOverlapping>Minimize</DataRequestOverlapping>"+nl);
	writer.write("<!-- The DRs receives a random frequency every run or non-random -->"+nl);
	writer.write("<DRFrequency>"+randomFreq+"</DRFrequency>"+nl);
	
	writer.write("</MultipleDataRequests>"+nl);
	
	writer.write("<InactiveNodes>"+nl);
	writer.write("<!-- Control Data rate transmitted by inactive nodes. In kbps-->"+nl);
	writer.write("<controlDataRate>1</controlDataRate>"+nl);
		
	writer.write("<!-- Frequency of communication of inactive nodes (nodes that aren't member of any group). In seconds -->"+nl);
	writer.write("<InactiveNodesFreq>10</InactiveNodesFreq>"+nl);
	writer.write("</InactiveNodes>"+nl);
	
	for(int i=0;i<nDR;i++){
		int nIntraGroup = (nNodes-1)/nDR;//1 node is the GW
	int countDR=i+1;
	
	int groupFrequency= 1;
	//int groupFrequency = 1 + (int)(Math.random() * ((5 - 1) + 1));
	
	
	writer.write(nl);
	
	writer.write("<!--  If the sum of all subset devices is higher than the total number of devices, so there will be overlapping  -->"+nl);	
	writer.write("<DataRequest>"+nl);
	writer.write("<!--  Char  -->"+nl);
	writer.write("<DR"+countDR+"-ID>"+this.groupLabels.get(i)+"</DR"+countDR+"-ID>"+nl);	
	writer.write("<!--  Seconds  -->"+nl);
	writer.write("<DR"+countDR+"-Frequency>"+groupFrequency+"</DR"+countDR+"-Frequency>"+nl);
	writer.write("<!--  Seconds  -->"+nl);
	writer.write("<DR"+countDR+"-DelayTolerance>0.5</DR"+countDR+"-DelayTolerance>"+nl);
	writer.write("<!--  Max, Min, Avg, Count, Merger  -->"+nl);
	writer.write("<DR"+countDR+"-AggFunction>Max</DR"+countDR+"-AggFunction>"+nl);
	writer.write("<DR"+countDR+"-QueryContent>"+nIntraGroup+"</DR"+countDR+"-QueryContent>"+nl);
	writer.write("</DataRequest>"+nl);
	
	}
	
	writer.write("</simulation>"+nl);
		
	
		
}
catch (Exception e) {e.printStackTrace();} 
finally {
try {writer.close();} 
catch (Exception e) {}
}

System.out.println("Output file: "+path+fileName+".xml");
}



// This method generate group labels. For example; AA, AB, AC, AD...
private void generateGroupLabels(){
	int count =0;

	for(int i=65; i<=90; i++){
		for(int j=65; j<=90; j++){
				count++;
				
				char s1 = (char)i;
				char s2 = (char)j;
				String s = new StringBuilder().append(s1).append(s2).toString();
				this.groupLabels.add(s);
				//System.out.println(count+" -- "+s);
}
//System.out.println();
		}
	}
	
	
}