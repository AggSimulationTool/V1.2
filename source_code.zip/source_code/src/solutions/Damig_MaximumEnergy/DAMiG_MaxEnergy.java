package solutions.Damig_MaximumEnergy;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import code.Network;

public class DAMiG_MaxEnergy {

	private Network s2;
	private double[][] weightedGraph;
	private InterGroupGraph intergg = new InterGroupGraph();
	private List<IntraGroupGraph> intragg = new ArrayList();
	private double[] residualEnergy; // The device index is the index of array
	private int communicationRound=0;
	private boolean conectivity = true;
	private double sumIntraEnergy=0;
	private double sumInterEnergy=0;

	
	public void simulation(){

		//Initialize the variable that controls if any node is dead.
		boolean anyNodeDead=false;
	 	
		//Initialize the residual Energy
		this.initializeResidualEnergy();
	 	
	 	//It starts the time start in 1
	 	this.s2.setTime(1); 
		
		while(anyNodeDead != true && this.conectivity == true){
			
			//Based on the Link Cost Equation, it computes the Weighted Graph Matrix
			this.initializeWeightedGraph();
			
			//Update the Communication  Rounds
			communicationRound++;
			
			//Find which groups the Set of Communicating Groups of this particular round.
			this.s2.findCommunicatingGroups();
			
			// Instatiate the Inter Group Graph.
			this.setInterGroupGraph();
			
			// Compute the Inter Group MST
			this.intergg.computeMST();
			
			// It counts the number of Receptions the node in the Inter Group Edges executes.
			this.countRxInterGroupEdges();
			
			// To aggregate the messages, it is necessary to know a order of communication. This is performed using the Breadth-first search (BFS) algorithm.
			this.intergg.BFS(this.s2.getGatewayLabelGroup());
			
			// Based on the BSF order, it update the number of aggregated messages.
			this.intergg.updateAmountData();
			
			// It sorts the used edges
			this.intergg.moveEdges(); 
			
			// It prints the Inter Group Graphs
			//this.intergg.printInterGroupGraph();
			
			// Set the Intra Group Graphs
			this.setIntraGroupGraph();
			
			// Set the intra Root of each group
			this.setIntraRoot();
			
			// Computes the Destination Oriented Directed Acyclic Graph (DODAG). A intra Group Graph is transformed into DODAG.
			this.computeAllDODAGs();
			
			// It selects the parent having the highest residual energy in each DODAG.
			this.selectIntraGMaxEnergyParent();
		  
			// test to see if the selected DODAG edges of a group is a connected graph. 
			//This test is necessary once, since the intra graph does not change.
			// In case of mobility this test should be repeated.
			if(communicationRound==1) this.conectivity=this.MSTconectivityTest();
			
			// It computes the order of communication using the Breadth-first search (BFS)
			this.computeBFSintraGroupOrder();
			
			// test to see if every device of a group belong to the DODAG. This test is necessary once, since the intra graph does not change
			// In case of mobility this test should be repeated.
			if(communicationRound==1) this.conectivity=this.finalConnectivityTest(); 
			
			//Print the Residual Energy 
				System.out.println("\n\n\n ====  ROUND NUMBER "+communicationRound+" ====");	
				this.printEnergy();
	
			// Aggregate the mesages
			this.updateAmountDataAllGroups();
			
			// It computes and deducts the 
			this.deductIntraGroupEnergy();
			
			this.deductSPenergy();
			
			anyNodeDead = this.isAnyDeviceDead(communicationRound);		 
			
			this.s2.incrementTime();
		 
		 //In each time instant, the objects and variables should be cleared
		 this.s2.clearCommunicatingGroups();
		 this.intergg.deleteInterGroupGraph();
		 this.clearAllIntraGroupGraph();
		 System.gc();
		}	
	}
	
	
	public void setNetwork(Network N){
		this.s2=N;
	}
	
	public int getCommunicationRounds(){
		return this.communicationRound;
	}
	
	public double getResidualEnergy(int index){
		return this.residualEnergy[index];
	}
	
	public double getAvgResidualEnergy(){
		double avgEnergy;
		double sum=0;
		for(int i=0; i<this.residualEnergy.length;i++){
			if(i != this.s2.getGatewayIndex())
			sum=sum + this.residualEnergy[i];
		}
		avgEnergy=sum/(this.residualEnergy.length -1);
		return avgEnergy;
	}
	
	public double getSumIntraEnergy(){
		return this.sumIntraEnergy;
	}
	
	public double getSumInterEnergy(){
		return this.sumInterEnergy;
	}
	
	public boolean isAnyDeviceDead(int round){
		for(int i=0;i<this.residualEnergy.length;i++){
			if(this.residualEnergy[i]<0){
				System.out.println("\n\n\n ==================== END! ==================== ");
				System.out.println("Device "+i+", Energy "+this.residualEnergy[i]+" round "+round);
				return true;
			}
		}
		return false;
	}
	
	public void printEnergy(){
		System.out.print("\n");
		for(int i=0;i<this.residualEnergy.length;i++){
			System.out.println("Device "+i+" energy "+this.residualEnergy[i]);
		}
	}
	
	public void setInterGroupGraph(){
		//Default is 1
		int numOfGateways=1;

		String groupSender, groupReceiver;
		String Rcv, Sdr;
		float pathCost;
		//--System.out.println();
		// These two fors do every possible combinations of groups
		for(int i=0; i<this.s2.getSizeCommunicatingGroups();i++){

			
			for(int j=i+1; j<this.s2.getSizeCommunicatingGroups();j++){
				
				// Find the Sender and Receiver of every Inter Group Graph edge
				groupSender=this.s2.getCommunicatingGroups(i);
				
				groupReceiver=this.s2.getCommunicatingGroups(j);
				
				//Tentative to include the GW in the groups that have a direct link to it.
				//If the sender group does not have direct link to the GW, then the Shrotest Path Should be computed
				//if(groupSender have direct link with the GW == true)
				
				//--System.out.println("\nComputing "+groupSender+"->"+groupReceiver);
				Rcv=this.selectReceiver(groupSender, groupReceiver);
				
				// Select an receiver node in the receiver group
				//--System.out.println("\nComputing "+groupReceiver+"->"+groupSender);
				Sdr=this.selectReceiver(groupReceiver, groupSender);
				
				//--System.out.println("\nSP between "+Sdr+" and "+Rcv);
				// dijstra's parameters is index and not label
				this.dijstra(this.s2.findIndexDevice(Sdr), this.s2.findIndexDevice(Rcv), groupReceiver, groupSender);
			}
		}
	}

	// Compute the shortest path between the sender index and receiver index
	public void dijstra(int senderIndex, int receiverIndex, String groupReceiver, String groupSender){
		
		double [] costVector =new double [this.weightedGraph.length]; // Store the cost to transmit from sender to receiver. The index of costVector is the node index
		List<Integer> selectedNodes = new ArrayList<Integer>(); // Store the selected nodes indexes
		List<Integer> unvisitedNodes = new ArrayList<Integer>(); // Store the unvisited nodes indexes
		int nodeIndex=senderIndex; // It is the node index that is unvisited and has minimum cost
		double minCostValue;
		double minCostValueTemp=0;
		double sumCostValue=0;
		int unvisitedIndex=0;
		double highValue=Double.MAX_VALUE;
		
		
		for(int i=0;i<this.weightedGraph.length;i++){	
			costVector[i]=highValue;  // Set a very high value to all nodes		
			unvisitedNodes.add(i);  //Add all nodes indexes in unvisited list
		}
		
		costVector[senderIndex]=0; // Distance from sender to sender

		
		while(unvisitedNodes.isEmpty() == false){
			minCostValue=highValue;
			for(int i=0;i<unvisitedNodes.size();i++){
				if(minCostValue>costVector[unvisitedNodes.get(i)]){
					minCostValue=costVector[unvisitedNodes.get(i)]; // The min cost value 
					nodeIndex=unvisitedNodes.get(i);	// Find the unvisited node with min cost 
					unvisitedIndex=i;
				}
			}
			//System.out.println("Min distance node selected "+this.s1.getDevice(MinDisIndex).getLabel());
			
			
			// End
			if(nodeIndex==receiverIndex){
				selectedNodes.add(nodeIndex);
				break;
			}
			
			
			//System.out.println("MinDisIndex "+ MinDisIndex );
			//System.out.println("Size of Univisited Nodes Indexes "+unvisitedNodesIndexes);
			//Remove the min node index from unvisited
			unvisitedNodes.remove(unvisitedIndex);
			
			// all remaining vertices are inaccessible from source
			if(costVector[nodeIndex]==highValue)
				break;
			
			//for each neighbor of MinDisIndex
			for(int i=0;i<this.weightedGraph.length;i++){
				//Condition for i be neighbor of MinDisIndex
				if((this.weightedGraph[nodeIndex][i]>= 0) && (unvisitedNodes.contains(i))){
					//--System.out.println("Neighbor of "+this.s1.getDevice(MinDisIndex).getLabel()+" is "+this.s1.getDevice(i).getLabel());
					//--System.out.println("dist["+this.s1.getDevice(i).getLabel()+"] "+distanceSdrRcv[i]);

					minCostValueTemp=costVector[nodeIndex]+this.weightedGraph[nodeIndex][i];
					//--System.out.println("Update distance "+updateDistance);
					if(minCostValueTemp<costVector[i]){
						//System.out.println("Teste");
						costVector[i]=minCostValueTemp;
						if(!selectedNodes.contains(nodeIndex)){
							selectedNodes.add(nodeIndex);
						}
					}
				}
			}
	}
		//--System.out.println("Selected nodes ");
		for(int i=0;i<selectedNodes.size();i++){
			//--System.out.print(this.s1.getDevice(selectedNodesIndexes.get(i)).getLabel()+" ");
			sumCostValue=sumCostValue+costVector[selectedNodes.get(i)];
		}
		//--System.out.println("\nDistance: "+sumCost);
		this.intergg.addEdge(receiverIndex, senderIndex, groupReceiver, groupSender, sumCostValue, selectedNodes);
		//--System.out.print("\nGroup "+groupSender+ " Node "+ senderIndex + " for Group " + groupReceiver+ " Node "+receiverIndex);
}
	
    // Select the node to be the Inter Receiver
	public String selectReceiver(String groupSender, String groupReceiver){
		String labelReceiver=null;
		List<String>nodesOfGroupSender = new ArrayList();
		List<String>nodesOfGroupReceiver = new ArrayList();
		int receiverIndex, senderIndex;
		double cost=0, costAux=0;
		float [] receiverCoord=new float [2];
		float [] senderCoord=new float [2];
		// To compute the best sender-receiver pair is necessary to choose one node 
		// located in the sender group and compute the distance of this nodes and all nodes in the receiver group. 
		nodesOfGroupSender=this.s2.findDevicesOfGroup(groupSender);
		nodesOfGroupReceiver=this.s2.findDevicesOfGroup(groupReceiver);
		
		// Pick any node in the sender group. In this case, it is the first one
		senderIndex=this.s2.findIndexDevice(nodesOfGroupSender.get(0));
		
		senderCoord[0]=this.s2.getDevice(senderIndex).getCoordX();
		senderCoord[1]=this.s2.getDevice(senderIndex).getCoordY();
		
		//  i is the index for nodes belonging to the receiver group
		for(int i=0;i<nodesOfGroupReceiver.size();i++){
			// compute the coordenates of the receiver
			receiverIndex = this.s2.findIndexDevice(nodesOfGroupReceiver.get(i));
			receiverCoord[0] = this.s2.getDevice(receiverIndex).getCoordX();
			receiverCoord[1] = this.s2.getDevice(receiverIndex).getCoordY();


			// First iteraction
			if(i==0){
				cost=(1 / this.residualEnergy[receiverIndex]);
				//cost=(Math.sqrt(Math.pow((receiverCoord[0]-senderCoord[0]),2)+Math.pow((receiverCoord[1]-senderCoord[1]),2) / this.residualEnergy[receiverIndex]));
				//cost=Math.sqrt(Math.pow((receiverCoord[0]-senderCoord[0]),2)+Math.pow((receiverCoord[1]-senderCoord[1]),2));
				labelReceiver=nodesOfGroupReceiver.get(i);
			}
			// Other iteractions
				
			costAux= (1/ this.residualEnergy[receiverIndex]);
				//costAux= (Math.sqrt(Math.pow((receiverCoord[0]-senderCoord[0]),2)+Math.pow((receiverCoord[1]-senderCoord[1]),2) / this.residualEnergy[receiverIndex] ));
				//costAux= Math.sqrt(Math.pow((receiverCoord[0]-senderCoord[0]),2)+Math.pow((receiverCoord[1]-senderCoord[1]),2) );
				//System.out.println("Distance between "+ nodesOfGroupReceiver.get(i) + " and " + nodesOfGroupSender.get(0)+ " is " +costAux);
				if(costAux<cost){
					cost=costAux;
					//Find the minimum receiver
					labelReceiver=nodesOfGroupReceiver.get(i);
				}
			
		}
		
		nodesOfGroupSender= null;
		nodesOfGroupReceiver = null;
		receiverCoord = null;
		senderCoord = null;
		
		
		//--System.out.println("Receiver for group "+groupSender+" is "+labelReceiver);
		return labelReceiver;
	}
		
	public void initializeWeightedGraph(){
		boolean linkMatrix [][];
		linkMatrix=s2.getLinkMatrix();		
		this.weightedGraph =new double[linkMatrix.length][linkMatrix.length];
		float distance;
		float n1X, n1Y, n2X, n2Y;
		
		for(int i=0;i<this.weightedGraph.length;i++){
			for(int j=i;j<this.weightedGraph.length;j++){
				if(linkMatrix[i][j]){					
					distance = this.s2.findDistance(i, j);					
					// the matrix is symmetric
					//System.out.println("Rx "+(float)this.computeEnergyRx(distance, 1));
					this.weightedGraph[i][j]=(this.computeEnergyTx(distance, 1) + (this.computeEnergyRx(distance, 1)) / (this.residualEnergy[i]) + (this.residualEnergy[j]));
					this.weightedGraph[j][i]=(this.computeEnergyTx(distance, 1) + (this.computeEnergyRx(distance, 1)) / (this.residualEnergy[i]) + (this.residualEnergy[j]));
					//this.weightedGraph[i][j]=distance;
					//this.weightedGraph[j][i]=distance;
				}
				else{
					// -1 indicates that there is no link between the nodes
					this.weightedGraph[i][j]=-1;
					this.weightedGraph[j][i]=-1;
				}
			}
		}
	}

	public void printWeightedGraph(){
	System.out.print("\n\nPrinting weighted graph");
	for (int i=0;i<this.weightedGraph.length;i++){
		System.out.println();
		for(int j=0;j<this.weightedGraph.length;j++)
			System.out.print(this.weightedGraph[i][j]+" ");
	}
}
	
	//It defines some settings for the Intra Groups
	public void setIntraGroupGraph(){
		List<String> devicesOfGroup = new ArrayList();
		int indexDevice;
		//--System.out.println();

		for(int i=0;i<this.s2.getSizeCommunicatingGroups();i++){
			IntraGroupGraph intraGG = new IntraGroupGraph();

			//--System.out.print("\nCreating the intra group graph "+ this.s1.getCommunicatingGroups(i));
			
			// Create and add a new intra group graph for each communicating group
			intraGG.setGroupLabel(this.s2.getCommunicatingGroups(i));
			// find the nodes that belong to that group
			devicesOfGroup = this.s2.findDevicesOfGroup(this.s2.getCommunicatingGroups(i));
			// look for edges in weighted graph
				for(int j=0;j<this.weightedGraph.length;j++){
					for(int k=j+1;k<this.weightedGraph.length;k++){
						if(this.weightedGraph[j][k] > 0 && (devicesOfGroup.contains(this.s2.getDevice(j).getLabel()) && devicesOfGroup.contains(this.s2.getDevice(k).getLabel()))){
							intraGG.addEdge(j, k, this.weightedGraph[j][k]);
							//--System.out.println("New edge added. Sender "+ this.s1.getDevice(j).getLabel() +" Receiver " + this.s1.getDevice(k).getLabel() + " weight " + this.weightedGraph[j][k]);
						}
					}
				}
			this.intragg.add(intraGG);
		}
	}
	
	// It computes the Destination Oriented Directed Acyclic Graph (DODAG)
	public void computeAllDODAGs(){
		for(int i=0;i<this.intragg.size();i++){
			this.intragg.get(i).computeDODAG();
		}
	}

	// It tests the connectivity of the Intra Groups Trees
	public boolean MSTconectivityTest(){
		boolean conect = true;
		System.out.print("\n\nTest of connectivity for Intra Group Nodes:");
		System.out.println("Number of groups "+this.intragg.size() );
		
		for(int i=0;i<this.intragg.size();i++){
			if(this.intragg.get(i).connectedTest()==false){
				System.out.println("\n\n\n\nGroup "+this.intragg.get(i).getGroupLabel()+ " did not form a connected graph");
				System.out.println("Stopping the execution");
				conect=false;
			}
		}
		return conect;
	}
		
	// It selects the parent having the highest residual energy.
	public void selectIntraGMaxEnergyParent(){
		List<String>nodesOfGroup = new ArrayList();
		String groupLabel;
		int devIndex;
		
		for(int i=0;i<this.intragg.size();i++){
			groupLabel=this.intragg.get(i).getGroupLabel();
			//--System.out.println("\n--- Group "+groupLabel);
			nodesOfGroup=this.s2.findDevicesOfGroup(groupLabel);
			for(int j=0;j<nodesOfGroup.size(); j++){
				devIndex=this.s2.findIndexDevice(nodesOfGroup.get(j));
				if(devIndex != this.intragg.get(i).getDeviceIndexRoot()  && devIndex!=this.s2.getGatewayIndex())
				this.intragg.get(i).selectParent(devIndex);
			}
		}
		
	}
	
	// It counts how many receptions the nodes in the Inter Group Edges executes.
	public void countRxInterGroupEdges(){
		String groupLabel;
		int nEdges;
		//--System.out.print("\n\nThe number of childs of each Inter Group Graph Node:");
		for(int i=0;i<this.s2.getSizeCommunicatingGroups();i++){
			groupLabel=this.s2.getCommunicatingGroups(i);
			nEdges=this.intergg.countEdgesOnMST(groupLabel);
			if(groupLabel != this.s2.getGatewayLabelGroup())
				nEdges=nEdges-1;
				//--System.out.print("\nChids of group "+groupLabel+" is "+nEdges);
		}
		
	}

	public void setIntraRoot(){
		String groupLabel;
		int intraRootDeviceIndex;
		for(int i=0;i<this.intragg.size();i++){
			groupLabel=this.intragg.get(i).getGroupLabel();
			intraRootDeviceIndex=this.intergg.getSenderIndexOnMST(groupLabel);
			//--System.out.println("\n root of "+groupLabel +" is "+intraRootDeviceIndex);
			this.intragg.get(i).setDeviceIndexRoot(intraRootDeviceIndex);
		}
	}

	// It is necessary to compute a communication order. This is computed based on the Breadth-first search (BFS)
	public void computeBFSintraGroupOrder(){
		for(int i=0;i<this.intragg.size();i++){
			if(this.intragg.get(i).getGroupLabel() != this.s2.getGatewayLabelGroup() )
			this.intragg.get(i).BFS();
		}
	}
	
	public boolean finalConnectivityTest(){
		boolean conect=true;
		System.out.print("\n\nFinal Test of connectivity for Intra Nodes:");
		
		for(int i=0;i<this.intragg.size();i++){
			if((this.intragg.get(i).getGroupLabel() != this.s2.getGatewayLabelGroup() ) && (this.intragg.get(i).getOrderDeviceIndexes().size() != this.s2.findDevicesOfGroup(this.intragg.get(i).getGroupLabel()).size())){
				System.out.println("\n\n\n\nGroup "+this.intragg.get(i).getGroupLabel()+ " has a device not connected");
				System.out.println("Stopping the execution");
				conect=false;
			}
			else
				System.out.print("\nGroup "+this.intragg.get(i).getGroupLabel()+ " --- OK");
		}		
		return conect;
	}

	public int findIntraGroupIndex(String groupLabel){
		int indexIntraGroup=-1;
		
		for(int i=0;i<this.intragg.size();i++){
			if(this.intragg.get(i).getGroupLabel() == groupLabel)
				indexIntraGroup = i;
		}
		return indexIntraGroup;
	}
	
	public void initializeResidualEnergy(){
		this.residualEnergy = new double [this.s2.getLinkMatrix().length];
		for(int i=0; i<this.s2.getLinkMatrix().length;i++){
			this.residualEnergy[i]=this.s2.getDevice(i).getInitialEnergy();
		}
	}
	
	
	public void updateAmountDataAllGroups(){
		int nMgs;
		int interNodeRcv;
		String groupLabel;
		int groupIndex;
		
		for(int i=0;i< this.intergg.getListEdges().size();i++){
			if(this.intergg.getListEdges().get(i).isSelectedForMST() == true && this.intergg.getListEdges().get(i).getReceiver().getReceiverDeviceIndex() != -1 ) {
				nMgs = (int) this.intergg.getListEdges().get(i).getReceiver().getAmountData();
				interNodeRcv = this.intergg.getListEdges().get(i).getReceiver().getReceiverDeviceIndex();
				groupLabel = this.intergg.getListEdges().get(i).getReceiver().getGroupLabel();
				groupIndex = this.findIntraGroupIndex(groupLabel);
				this.intragg.get(groupIndex).updateInterLoad(interNodeRcv, nMgs);//call increment for all groups
			}
		}
	}
	
	
	public void deductIntraGroupEnergy(){
		String groupLabel;
		int deviceIndexSdr, deviceIndexRcv;
		double energyCostTx;
		double energyCostRx;
		float nMsgs;
		float distance;
		float load;
		
		//--System.out.print("\n\n\nAll Intra Group TX and RX");
		
		for(int i=0;i<this.intragg.size();i++){ //do this for all groups
			groupLabel = this.intragg.get(i).getGroupLabel();
			//--System.out.print("\n\nGroup "+groupLabel);
			for(int j=0;j<this.intragg.get(i).getListEdges().size();j++){
				if(this.intragg.get(i).getListEdges().get(j).isSelectedForMST() == true ){
					deviceIndexSdr = this.intragg.get(i).getListEdges().get(j).getSender().getDeviceIndex();
					deviceIndexRcv = this.intragg.get(i).getListEdges().get(j).getReceiver().getDeviceIndex();
					distance = this.s2.findDistance(deviceIndexSdr, deviceIndexRcv);
					// TRANSMISSION
					// ------------------------------------------------------------------------------- Find the number of messages
					nMsgs=this.intragg.get(i).getListEdges().get(j).getAmountData();
					// Find the energy cost for Tx
					energyCostTx = this.computeEnergyTx(distance, nMsgs);
					// Deducts the energy cost from the residual energy of sender
					this.residualEnergy[deviceIndexSdr] = this.residualEnergy[deviceIndexSdr] - energyCostTx;
					
					//--System.out.print("\nDevice "+deviceIndexSdr+" Tx to "+ deviceIndexRcv + " " + nMsgs + " msgs consuming " + energyCost);
					// RECEPTION
					// the number of messages is the same for all nodes inside the group
					// Find the energy cost for Rx
					energyCostRx = this.computeEnergyRx(distance, nMsgs);
					// Deducts the energy cost from the residual energy of receiver
					this.residualEnergy[deviceIndexRcv] = this.residualEnergy[deviceIndexRcv] - energyCostRx;
					//--System.out.print("\nDevice "+ deviceIndexRcv +" Rx from " + deviceIndexSdr + " " + nMsgs + " msgs consuming " + energyCost);
					this.sumIntraEnergy=this.sumIntraEnergy+energyCostTx+energyCostRx; 
				}
			}
		}
	}

	public void deductSPenergy(){
		List<Integer> listDevIndex;
		int deviceIndexSdr, deviceIndexRcv;
		float distance;
		float nMsgs;
		double energyCostTx;
		double energyCostRx;
		
		//--System.out.print("\n\n\nAll SP TX and RX");
		for(int i=0; i<this.intergg.getListEdges().size();i++){
			if(this.intergg.getListEdges().get(i).isSelectedForMST()){
				//--System.out.print("\n\nSP "+ this.intergg.getListEdges().get(i).getSender().getGroupLabel()+" --> "+ this.intergg.getListEdges().get(i).getReceiver().getGroupLabel());
				listDevIndex = this.intergg.getListEdges().get(i).getDeviceIndexesSP();
				//--System.out.print("\nSize of SP list "+listDevIndex.size());
				for(int k=0;k+1<listDevIndex.size();k++){
						deviceIndexSdr=listDevIndex.get(k);// find the distance
						deviceIndexRcv=listDevIndex.get(k+1);
						distance = this.s2.findDistance(deviceIndexSdr, deviceIndexRcv);
						nMsgs = this.intergg.getListEdges().get(i).getAmountDataEdge();
						energyCostTx = this.computeEnergyTx(distance, nMsgs);
						this.residualEnergy[deviceIndexSdr] = this.residualEnergy[deviceIndexSdr] - energyCostTx;
						//--System.out.print("\nDevice "+deviceIndexSdr+" Tx to "+ deviceIndexRcv + " " + nMsgs + " msgs consuming " + energyCost);
						energyCostRx = this.computeEnergyRx(distance, nMsgs);
						this.residualEnergy[deviceIndexRcv] = this.residualEnergy[deviceIndexRcv] - energyCostRx;
						//--System.out.print("\nDevice "+deviceIndexRcv+" Rx from "+ deviceIndexSdr + " " + nMsgs + " msgs consuming " + energyCost);
						this.sumInterEnergy=this.sumInterEnergy+energyCostTx+energyCostRx; // count 1 header for each interGraph edge
				}
			}
		}
	}
	
	public double computeEnergyTx(float distance, float nMsgs){
		// Tx = nbits.50nJ/bit + nbits.100pJ/bit/m * distance^2
		double elec=50*(Math.pow(10, -9)); // Energy required to run the circuit 50nJ/bit
		double amp = 100*(Math.pow(10, -12)); // Energy required to tx
		float singleMsgLength = 4 * 8; // in bits
		float headerLength = 12 * 8; // in bits
		double nBits = headerLength + (singleMsgLength * nMsgs);
		double turnonCost = 0.000022;//Cost to turn on the device and the radio (in Joules)
		double energyCost = (nBits*elec) + (nBits*amp*Math.pow(distance, 2))+turnonCost;
		
		return energyCost;
	}

	public double computeEnergyRx(float distance, float nMsgs){
		// Rx = nbits.50nJ/bit
		double elec=50*(Math.pow(10, -9)); // Energy required to run the circuit 50nJ/bit
		float singleMsgLength = 4 * 8; // in bits
		float headerLength = 12 * 8; // in bits
		double nBits = headerLength + (singleMsgLength * nMsgs);
		double turnonCost = 0.000022;//Cost to turn on the device and the radio (in Joules)
		double energyCost = nBits*elec + turnonCost;
		
		return energyCost;
	}
	
	public void getCoordInterGroupEdges(){
		int i, j, index;
		List<Integer> listDevIndex;
		
		for(i=0;i<intergg.getListEdges().size();i++){
			if(intergg.getListEdges().get(i).isSelectedForMST()) {
				for(j=0;j<intergg.getListEdges().get(i).getDeviceIndexesSP().size()-1; j++) {
					index=intergg.getListEdges().get(i).getDeviceIndexesSP().get(j);
					this.s2.getDevice(index).getCoordX();
					this.s2.getDevice(index).getCoordY();
				}
			}
		}
		
	}
	
	public void clearAllIntraGroupGraph(){
		for(int i=0;i<this.intragg.size();i++){
			intragg.get(i).clearIntraGroupGraph();
		}
		this.intragg.clear();
		//this.intragg=null;
	}

	


	
}
