package solutions.Damig_MaximumEnergy;

import java.util.ArrayList;
import java.util.List;

public class InterGroupGraph {

	private String ID;
	private List<String> orderGroupLabels = new ArrayList<String>();
	private List<EdgeInterGroup> listEdges = new ArrayList<EdgeInterGroup>();

	

	public List<EdgeInterGroup> getListEdges() {
		return listEdges;
	}
	
	public void addEdge(int receiverDeviceIndex, int senderDeviceIndex, String receiverGroupLabel, String senderGroupLabel, double weight, List<Integer> deviceIndexesSP){
		EdgeInterGroup e = new EdgeInterGroup();
		e.setReceiver(receiverDeviceIndex, receiverGroupLabel);
		e.setSender(senderDeviceIndex, senderGroupLabel);
		e.setWeight(weight);
		e.setDeviceIndexesSP(deviceIndexesSP);
		
		this.listEdges.add(e);
	}


	
	
	public void computeMST(){
		boolean senderNoComponent, receiverNoComponent, testDiffComponent;
		int componentCounter=0;
		int changeComponentID;
		
		// Order the listEdge
		this.orderListEdges();
		
		
		for(int i=0;i<this.listEdges.size();i++){
			if(this.listEdges.get(i).getSender().getMSTcomponent()==0)
				senderNoComponent=true;
			else
				senderNoComponent=false;
			if(this.listEdges.get(i).getReceiver().getMSTcomponent()==0)
				receiverNoComponent=true;
			else
				receiverNoComponent=false;

			if(this.listEdges.get(i).getSender().getMSTcomponent() != this.listEdges.get(i).getReceiver().getMSTcomponent())
				testDiffComponent=true;
			else
				testDiffComponent=false;
				
							
				if((senderNoComponent||receiverNoComponent)||testDiffComponent){
					this.listEdges.get(i).setSelectedForMST(true);
					//--System.out.println("\nEdge selected: "+this.listEdges.get(i).getSender().getGroupLabel()+" - "+this.listEdges.get(i).getReceiver().getGroupLabel()+"        Weight "+this.listEdges.get(i).getWeight());

					
					// If sender and receiver belong to any component
					if(senderNoComponent && receiverNoComponent){
						componentCounter++;
						this.changeGroupComponent(this.listEdges.get(i).getSender().getGroupLabel(), componentCounter);
						this.changeGroupComponent(this.listEdges.get(i).getReceiver().getGroupLabel(), componentCounter);
						//--System.out.println("All edges with group label "+ this.listEdges.get(i).getSender().getGroupLabel()+" belongs to the new component "+ componentCounter);
						//--System.out.println("All edges with group label "+ this.listEdges.get(i).getReceiver().getGroupLabel()+" belongs to the new component "+ componentCounter);
					}
				
					// If sender or receiver belong to a component
					else if(((!senderNoComponent) && (!receiverNoComponent)) && testDiffComponent){
						//--System.out.println("All group labels from component "+this.listEdges.get(i).getReceiver().getMSTcomponent()+" now belongs to the component "+ this.listEdges.get(i).getSender().getMSTcomponent());
						this.changeComponent(this.listEdges.get(i).getReceiver().getMSTcomponent(), this.listEdges.get(i).getSender().getMSTcomponent());
					}
				
				
					if(senderNoComponent&&(!receiverNoComponent)){
						//--System.out.println("All edges with group label "+this.listEdges.get(i).getSender().getGroupLabel()+" now belongs to the component "+ this.listEdges.get(i).getReceiver().getGroupLabel());
						this.changeGroupComponent(this.listEdges.get(i).getSender().getGroupLabel(),this.listEdges.get(i).getReceiver().getMSTcomponent());
					}
					
					if(receiverNoComponent&&(!senderNoComponent)){
						//--System.out.println("All edges with group label "+ this.listEdges.get(i).getReceiver().getGroupLabel()+" now belongs to the component "+ this.listEdges.get(i).getSender().getGroupLabel());
						this.changeGroupComponent(this.listEdges.get(i).getReceiver().getGroupLabel(),this.listEdges.get(i).getSender().getMSTcomponent());
					}
				

				}
			}
		
		
		}

	
	public void changeComponent(int oldComponent, int newComponent){
		for(int i=0;i<this.listEdges.size();i++){
			if(this.listEdges.get(i).getSender().getMSTcomponent()==oldComponent)
				this.listEdges.get(i).getSender().setMSTcomponent(newComponent);
			
			if(this.listEdges.get(i).getReceiver().getMSTcomponent()==oldComponent)
				this.listEdges.get(i).getReceiver().setMSTcomponent(newComponent);
		}
	}
	
	// Change the group component matching a particular group label
	public void changeGroupComponent(String groupLabel, int newComponent){
		for(int i=0;i<this.listEdges.size();i++){
			if(this.listEdges.get(i).getSender().getGroupLabel().equals(groupLabel))
				this.listEdges.get(i).getSender().setMSTcomponent(newComponent);
			
			if(this.listEdges.get(i).getReceiver().getGroupLabel().equals(groupLabel))
				this.listEdges.get(i).getReceiver().setMSTcomponent(newComponent);
		}
	}
	
	// Order the edges in increasing order according to the weight
	public void orderListEdges(){
		  int lenD=this.listEdges.size();
		  EdgeInterGroup tmpEdge;
		  for(int i = 0;i<lenD;i++){
		    for(int j = (lenD-1);j>=(i+1);j--){
		      if(this.listEdges.get(j).getWeight()<this.listEdges.get(j-1).getWeight()){
		        tmpEdge = this.listEdges.get(j);
		        
		        this.listEdges.set(j, this.listEdges.get(j-1));
		        
		        this.listEdges.set(j-1, tmpEdge);
		      }
		    }
		  }
		}
	
	
	
	public void printInterGroupGraph(){
		int i;
		System.out.print("\nPrinting inter group graph\n");
		for(i=0;i<this.getListEdges().size();i++){
			if(this.listEdges.get(i).isSelectedForMST())
			System.out.println(this.listEdges.get(i).getSender().getGroupLabel()+" - "+this.listEdges.get(i).getReceiver().getGroupLabel()+" weight "+this.getListEdges().get(i).getWeight());
		}
		
	}

	
	// It Computes the number of edges having an particular group label 
	public int countEdgesOnMST(String groupLabel){
		int countEdges=0;
		for(int i=0;i<this.listEdges.size();i++){
			if((this.listEdges.get(i).isSelectedForMST() == true) && (this.listEdges.get(i).getReceiver().getGroupLabel() == groupLabel || this.listEdges.get(i).getSender().getGroupLabel() == groupLabel) ){
					countEdges++;
				}
			}
		return countEdges;
	}

	//It Computes Breath First Search Order 
	public void BFS(String root){
		List<String> Q = new ArrayList();
		String v, w;
		
		Q.add(root);
		//--System.out.println("\n\n\nBreath First Search Order: ");
		this.markMSTnode(root);

		
		while(Q.isEmpty() == false){
			v=Q.get(0);
			Q.remove(0);
			//--System.out.print(v+" <- " );
			this.orderGroupLabels.add(v);
			for(int i=0;i<this.listEdges.size();i++){
				if(this.listEdges.get(i).isSelectedForMST() == true && this.listEdges.get(i).getReceiver().getGroupLabel().equals(v)){
					w=this.listEdges.get(i).getSender().getGroupLabel();
					if(this.listEdges.get(i).getSender().isBSTmark() == false){
						this.markMSTnode(w);
						Q.add(w);
					}
				}
				else if (this.listEdges.get(i).isSelectedForMST() == true && this.listEdges.get(i).getSender().getGroupLabel().equals(v)){
					w=this.listEdges.get(i).getReceiver().getGroupLabel();
					if(this.listEdges.get(i).getReceiver().isBSTmark() == false){
						this.markMSTnode(w);
						Q.add(w);
					}
				}
			}

		}
		
	}
	
	// All groups having this groupLabel will be marked as true 
	public void markMSTnode(String groupLabel){
			for(int j=0;j<this.listEdges.size();j++){
				if(this.listEdges.get(j).getReceiver().getGroupLabel().equals(groupLabel)){
					this.listEdges.get(j).getReceiver().setBSTmark(true);
				}
				if(this.listEdges.get(j).getSender().getGroupLabel().equals(groupLabel)){
					this.listEdges.get(j).getSender().setBSTmark(true);
				}
			}
	}
	
	
	// Update the number of messages
	public void increamentAmountData(String groupLabel, float amountData){
		for(int j=0;j<this.listEdges.size();j++){
			if(this.listEdges.get(j).getReceiver().getGroupLabel().equals(groupLabel))
				this.listEdges.get(j).getReceiver().incrementAmountData(amountData);
			if(this.listEdges.get(j).getSender().getGroupLabel().equals(groupLabel))
				this.listEdges.get(j).getSender().incrementAmountData(amountData);
		}
}
	
	// Compute the amount of data (number of messages) transmitted between the groups
	public void updateAmountData(){
		String groupLabel;
		//--System.out.println("\n\nAmount of Data Transmitted");
		
		for(int k=this.orderGroupLabels.size()-1;k>0;k--){
		groupLabel=this.orderGroupLabels.get(k);
		
		
			for(int j=0;j<this.listEdges.size();j++){
				if(this.listEdges.get(j).isSelectedForMST()==true){
					if(this.listEdges.get(j).getReceiver().getGroupLabel().equals(groupLabel) && (this.listEdges.get(j).isTransmissionMark() == false )){
						this.increamentAmountData(this.listEdges.get(j).getSender().getGroupLabel(), this.listEdges.get(j).getReceiver().getAmountData());
						this.listEdges.get(j).setAmountDataEdge(this.listEdges.get(j).getReceiver().getAmountData());
						this.listEdges.get(j).setTransmissionMark(true);
						//--System.out.println(this.listEdges.get(j).getReceiver().getGroupLabel()+" transmit "+this.listEdges.get(j).getReceiver().getAmountData()+" message(s) to "+this.listEdges.get(j).getSender().getGroupLabel());
						this.listEdges.get(j).changeRcvSdr(); // Set the receiver as the sender and vice-versa. This is because before the MST and the BFS order, it is not possible to determine who is sender or receiver
						this.listEdges.get(j).invertOrderDevIndexSP();
					}
					else if(this.listEdges.get(j).getSender().getGroupLabel().equals(groupLabel) && (this.listEdges.get(j).isTransmissionMark() == false )){
						this.increamentAmountData(this.listEdges.get(j).getReceiver().getGroupLabel(), this.listEdges.get(j).getSender().getAmountData());
						this.listEdges.get(j).setAmountDataEdge(this.listEdges.get(j).getSender().getAmountData());
						this.listEdges.get(j).setTransmissionMark(true);
						//--System.out.println(this.listEdges.get(j).getSender().getGroupLabel()+" transmit "+this.listEdges.get(j).getSender().getAmountData()+ " message(s) to " +this.listEdges.get(j).getReceiver().getGroupLabel());
					}
				}
		
			}
		
		}
		
	}
	
	
	//Put the edges the selected MST edges before the non selected and in BFS Order
	public void moveEdges(){
		String groupLabel;
		EdgeInterGroup edgeTemp;
	
		//--System.out.println();
		
		for(int j=this.orderGroupLabels.size()-1;j>0;j--){
			groupLabel= this.orderGroupLabels.get(j);
	
			for(int i=0; i<this.listEdges.size();i++){
				if(this.listEdges.get(i).isSelectedForMST() == true && this.listEdges.get(i).getSender().getGroupLabel().equals(groupLabel)){
					//--System.out.println(this.listEdges.get(i).getSender().getGroupLabel() + " device index " + this.listEdges.get(i).getSender().getSenderDeviceIndex() + " ---> " + this.listEdges.get(i).getReceiver().getGroupLabel()+" device index "+this.listEdges.get(i).getReceiver().getReceiverDeviceIndex());
					edgeTemp=this.listEdges.get(i);
					this.listEdges.remove(i);
					this.listEdges.add(0, edgeTemp);
				}
			}
		}
	
	}
	
	public int getSenderIndexOnMST(String groupLabel){
		int deviceIndex=-1;
		//--System.out.println("\n Setting the root of Group "+ groupLabel);
		for(int i=0;i<this.listEdges.size();i++){
			if(this.listEdges.get(i).isSelectedForMST() == true){ 
				if (this.listEdges.get(i).getSender().getGroupLabel().equals(groupLabel)==true){
					deviceIndex=this.listEdges.get(i).getSender().getSenderDeviceIndex();
					//--System.out.println("1) The root is "+deviceIndex);
				}
			}
		}
		
		return deviceIndex;
	}
	
	public float findAmountData(String groupLabel){
		float amountData=1;
		for(int i=0; i<this.getListEdges().size();i++){
			if(this.getListEdges().get(i).isSelectedForMST() == true){
				if(this.getListEdges().get(i).getSender().getGroupLabel() == groupLabel)
					amountData = this.getListEdges().get(i).getSender().getAmountData();
			}
		}
		return amountData;
	}
	
	
	public void deleteInterGroupGraph(){
		this.ID=null;
		for(int i=0;i<this.listEdges.size();i++){
			this.listEdges.get(i).deleteEdgeInterGroup();
		}
			this.listEdges.clear();
	}
	
	

}




