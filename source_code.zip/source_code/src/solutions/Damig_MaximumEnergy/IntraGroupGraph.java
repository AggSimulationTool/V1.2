package solutions.Damig_MaximumEnergy;

import java.util.ArrayList;
import java.util.List;

public class IntraGroupGraph {
	private String groupLabel;
	private List<EdgeIntraGroup> listEdges = new ArrayList<EdgeIntraGroup>();
	private int deviceIndexRoot;
	private List<Integer> orderDeviceIndexes = new ArrayList<Integer>();
	private List<Integer> neighbourDeviceIndexes = new ArrayList<Integer>();

	
	public List getOrderDeviceIndexes(){
		return this.orderDeviceIndexes;
	}
	
	public int get1OrderDeviceIndex(int deviceIndex){
		return this.orderDeviceIndexes.get(deviceIndex);
	}
	
	public int getDeviceIndexRoot() {
		return deviceIndexRoot;
	}


	public void setDeviceIndexRoot(int deviceIndexRoot) {
		//System.out.println("Group "+this.groupLabel+" root "+deviceIndexRoot);
		this.deviceIndexRoot = deviceIndexRoot;
	}


	public String getGroupLabel(){
		return this.groupLabel;
	}


	public void setGroupLabel(String groupLabel) {
		this.groupLabel = groupLabel;
	}


	public List<EdgeIntraGroup> getListEdges() {
		return listEdges;
	}

	public void setListEdges(List<EdgeIntraGroup> listEdges) {
		this.listEdges = listEdges;
	}

	public void addEdge(int senderIndex, int receiverIndex, double weight){
		EdgeIntraGroup e = new EdgeIntraGroup();
		e.setSender(senderIndex);
		e.setReceiver(receiverIndex);
		e.setWeight(weight);
		
		this.listEdges.add(e);
	}
	
	// Destination Oriented Directed Acyclic Graph (DODAG)
	public void computeDODAG(){
		int newRank=0;
		int nIndex;
		
//--System.out.println("\nComputing rank of group "+this.getGroupLabel());
		
		this.neighbourDeviceIndexes.add(this.deviceIndexRoot);
		// Compute a Rank for edges linked to the intra root
		// Find the neighbours of root
	//--System.out.println("root is "+this.neighbourDeviceIndexes.get(0));
		
		while(this.neighbourDeviceIndexes.isEmpty()==false){
		
		nIndex=this.neighbourDeviceIndexes.get(0); // Get always the first element
		//-- System.out.println("n\nIndex: "+nIndex);
		this.neighbourDeviceIndexes.remove(0); // Remove always the first element
			
		for(int i=0;i<this.listEdges.size();i++){
			if((this.listEdges.get(i).getSender().getDeviceIndex()==nIndex)&&(this.listEdges.get(i).isDODAGmark()==false)){
				this.listEdges.get(i).setDODAGmark(true);//set true the nIndex
				//--System.out.println(this.listEdges.get(i).getSender().getDeviceIndex() + " is(a) Neighbour of "+this.listEdges.get(i).getReceiver().getDeviceIndex());
				newRank=this.listEdges.get(i).getSender().getRank()+1;
				this.updateRank(this.listEdges.get(i).getReceiver().getDeviceIndex(),newRank);
				//--System.out.println(this.listEdges.get(i).getSender().getDeviceIndex()+" rank " + this.listEdges.get(i).getSender().getRank()+ " "+ this.listEdges.get(i).getReceiver().getDeviceIndex() + " rank " + this.listEdges.get(i).getReceiver().getRank());
			    this.neighbourDeviceIndexes.add(this.listEdges.get(i).getReceiver().getDeviceIndex());
			}
			if((this.listEdges.get(i).getReceiver().getDeviceIndex()==nIndex)&&(this.listEdges.get(i).isDODAGmark()==false)){
				this.listEdges.get(i).setDODAGmark(true);//set true the nIndex
				//--System.out.println(this.listEdges.get(i).getReceiver().getDeviceIndex() + " is(b) Neighbour of "+this.listEdges.get(i).getSender().getDeviceIndex());
				newRank=this.listEdges.get(i).getReceiver().getRank()+1;
				this.updateRank(this.listEdges.get(i).getSender().getDeviceIndex(),newRank);
				//--System.out.println(this.listEdges.get(i).getReceiver().getDeviceIndex()+" rank " + this.listEdges.get(i).getReceiver().getRank()+ " "+this.listEdges.get(i).getSender().getDeviceIndex() + " rank " + this.listEdges.get(i).getSender().getRank());
			    this.neighbourDeviceIndexes.add(this.listEdges.get(i).getSender().getDeviceIndex());
			}
		}
		}
	}

	
	// It selects the parent having the highest residual energy.
	public void selectParent(int deviceIndex){
		int rank;
		double minCost=Double.MAX_VALUE;
		double auxCost=0;
		int neighbourDevIndex=0;
		int edgeIndex=0;
		int devSelected=0;
		
		//--System.out.println("\nSelecting parents of group "+this.groupLabel);
		//--System.out.println("Select a parent for the device "+deviceIndex);
		
		for(int i=0; i<this.listEdges.size();i++){
			if(this.listEdges.get(i).getReceiver().getDeviceIndex()==deviceIndex){
				neighbourDevIndex=this.listEdges.get(i).getSender().getDeviceIndex();
				auxCost=this.listEdges.get(i).getWeight();
				if((auxCost<minCost) && (this.listEdges.get(i).getSender().getRank() < this.listEdges.get(i).getReceiver().getRank() )){
					minCost=auxCost;
					edgeIndex=i;
					devSelected=neighbourDevIndex;
				}
			}
			if(this.listEdges.get(i).getSender().getDeviceIndex()==deviceIndex){
				neighbourDevIndex=this.listEdges.get(i).getReceiver().getDeviceIndex();
				auxCost=this.listEdges.get(i).getWeight();
				if((auxCost<minCost) && (this.listEdges.get(i).getReceiver().getRank() < this.listEdges.get(i).getSender().getRank())){
					minCost=auxCost;
					edgeIndex=i;
					devSelected=neighbourDevIndex;
				}
			}	
		}
		//--System.out.println("Device "+deviceIndex+" selected " + devSelected);
		//--System.out.println("The rank of device "+this.listEdges.get(edgeIndex).getReceiver().getDeviceIndex() +" is "+this.listEdges.get(edgeIndex).getReceiver().getRank());
		//--System.out.println("The rank of device "+this.listEdges.get(edgeIndex).getSender().getDeviceIndex() +" is "+this.listEdges.get(edgeIndex).getSender().getRank());
		this.listEdges.get(edgeIndex).setSelectedForDODAG(true);
	}
	
	
	
	// Rank is a measurement used to compute the DODAGs
	public void updateRank(int devIndex, int newRank){
		//Receive the device Index and update the new rank in all edges having this device.
	for(int i=0;i<this.listEdges.size();i++){
		if((this.listEdges.get(i).getReceiver().getDeviceIndex()==devIndex)&&((this.getListEdges().get(i).getReceiver().getRankUpdated()==false)||(this.listEdges.get(i).getSender().getDeviceIndex()==this.deviceIndexRoot))){
			this.listEdges.get(i).getReceiver().setDODAGRank(newRank);
			this.listEdges.get(i).getReceiver().setRankUpdated(true);
		}
		else if((this.listEdges.get(i).getSender().getDeviceIndex()==devIndex) &&((this.getListEdges().get(i).getSender().getRankUpdated()==false)||(this.listEdges.get(i).getReceiver().getDeviceIndex()==this.deviceIndexRoot))){
			this.listEdges.get(i).getSender().setDODAGRank(newRank);
			this.listEdges.get(i).getSender().setRankUpdated(true);
		}
	}
	
	}
	
	//Returns the Rank
	public int findRank(int devIndex){
		int rank=0;
		for(int i=0;i<this.listEdges.size();i++){
			if(this.listEdges.get(i).getReceiver().getDeviceIndex() == devIndex)
				rank=this.listEdges.get(i).getReceiver().getRank();
			else if(this.listEdges.get(i).getSender().getDeviceIndex() == devIndex)
				rank=this.listEdges.get(i).getSender().getRank();
		}
		//--System.out.println("The rank of "+devIndex+" is "+rank);
		return rank;
	}
	
	// It test all edges of a group
	public boolean connectedTest(){
		if(this.listEdges.isEmpty()==false){
			int component=this.listEdges.get(0).getSender().getComponent();
			System.out.print("\nTesting the connectivity of "+this.getGroupLabel());
			for (int i=0;i<this.listEdges.size();i++){
				if((this.listEdges.get(i).isSelectedForMST() == true) && (this.listEdges.get(i).getSender().getComponent() != component))
					return false;
				if((this.listEdges.get(i).isSelectedForMST() == true) && (this.listEdges.get(i).getReceiver().getComponent() != component))
					return false;
			}
			System.out.print(" --- OK");
			return true;
		}
		return true;
	}
	
	// It is useable for the connectivity test
	public void changeComponent(int oldComponent, int newComponent){
		for(int i=0;i<this.listEdges.size();i++){
			if(this.listEdges.get(i).getSender().getComponent()==oldComponent)
				this.listEdges.get(i).getSender().setComponent(newComponent);
			
			if(this.listEdges.get(i).getReceiver().getComponent()==oldComponent)
				this.listEdges.get(i).getReceiver().setComponent(newComponent);
		}
	}
	
	// It is useable for the connectivity test
	public void changeDeviceComponent(int deviceIndex, int newComponent){
		for(int i=0;i<this.listEdges.size();i++){
			if(this.listEdges.get(i).getReceiver().getDeviceIndex()==deviceIndex)
				this.listEdges.get(i).getReceiver().setComponent(newComponent);
			
			if(this.listEdges.get(i).getSender().getDeviceIndex()==deviceIndex)
				this.listEdges.get(i).getSender().setComponent(newComponent);
		}
	}
	
	// Put the edges in increase order of weight for the BFS
	public void orderListEdges(){
		  int lenD=this.listEdges.size();
		  EdgeIntraGroup tmpEdge;
		  for(int i = 0;i<lenD;i++){
		    for(int j = (lenD-1);j>=(i+1);j--){
		      if(this.listEdges.get(j).getWeight()<this.listEdges.get(j-1).getWeight()){
		        tmpEdge = this.listEdges.get(j);
		        
		        this.listEdges.set(j, this.listEdges.get(j-1));
		        
		        this.listEdges.set(j-1, tmpEdge);
		      }
		    }
		  }
		}
	
	
	// Receive the interRcv node and the intra sink node. This method updates all edges, until reach the intra sink node
	public void updateInterLoad(int interRcv, int nMgs){
		int indexParent;
		int indexRcv;
		if(this.groupLabel.equals("GW") == false){ //If the inter receiver is not the GW
			if(interRcv !=this.deviceIndexRoot){
			//System.out.print("\nThe Inter Receiver of Group " + this.groupLabel + " is "+ interRcv);
			//System.out.println("\nSink "+ this.deviceIndexRoot);
			}
			indexRcv = interRcv;
			//this.incrementData(indexParent, nMgs);

			while(indexRcv != 0){ // It repeates until there isn't parent
				indexParent = this.incrementParent(indexRcv, nMgs);
				indexRcv = indexParent;
			} 
		}
		//else
			//System.out.println("The Receiver Group is the GW");
		
	}
	
	
	// Find the MST parent node of the receiver
	public int incrementParent(int indexNode, int nMgs){ //It Receives as parameter the index of the Rcv node and update the Parent node 
		for(int i=0; i<this.listEdges.size();i++){			
			if((this.listEdges.get(i).isSelectedForMST() == true) && (this.listEdges.get(i).getSender().getDeviceIndex() == indexNode)){ // should be the Sender because the Inter Receiver is the first
				this.listEdges.get(i).incrementAmountData(nMgs); // The parent group increment the n msgs the child has.
				System.out.print("Node "+indexNode+" now has  "+this.listEdges.get(i).getAmountData()+" messages ");
				return this.listEdges.get(i).getReceiver().getDeviceIndex();
			}
		}
		return 0;	 // finished all parents	
	}
	
	
	public int countEdgesOnMST(int deviceIndex){
		int countEdges=0;
		for(int i=0;i<this.listEdges.size();i++){
			if(this.listEdges.get(i).getReceiver().getDeviceIndex() == deviceIndex || this.listEdges.get(i).getSender().getDeviceIndex() == deviceIndex)
				countEdges++;
		}
	return countEdges;
	}
	
	
	//It Computes Breath First Search Order. 
	public void BFS(){
		List<Integer> Q = new ArrayList();
		int v, w;
		
		// get the root of the intra group
		int root = this.deviceIndexRoot;
		
		
		Q.add(root);
		//--System.out.println("\n\n\nBreath First Search Order of Group "+this.groupLabel);
		this.markMSTnode(root);

		
		while(Q.isEmpty() == false){
			v=Q.get(0);
			Q.remove(0);
			//--System.out.print(v+" <- " );
			this.orderDeviceIndexes.add(v);
			for(int i=0;i<this.listEdges.size();i++){
				if(this.listEdges.get(i).isSelectedForMST() == true && this.listEdges.get(i).getReceiver().getDeviceIndex() == v){
					w=this.listEdges.get(i).getSender().getDeviceIndex();
					if(this.listEdges.get(i).getSender().isBSTmark() == false){
						this.markMSTnode(w);
						Q.add(w);
						//System.out.println("Receiver marked "+w);
					}
					this.listEdges.get(i).changeRcvSdr(); // because the v node must be always the receiver (the parent, not the child)
				}
				else if (this.listEdges.get(i).isSelectedForMST() == true && this.listEdges.get(i).getSender().getDeviceIndex() == v){
					w=this.listEdges.get(i).getReceiver().getDeviceIndex();
					if(this.listEdges.get(i).getReceiver().isBSTmark() == false){
						this.markMSTnode(w);
						Q.add(w);
						//System.out.println("Sender marked "+w);
					}
				}
			}
		}
	}
	
	
	// All groups having this groupLabel will be marked as true 
	public void markMSTnode(int deviceIndex){
			for(int j=0;j<this.listEdges.size();j++){
				if(this.listEdges.get(j).getReceiver().getDeviceIndex() == deviceIndex){
					this.listEdges.get(j).getReceiver().setBSTmark(true);
				}
				if(this.listEdges.get(j).getSender().getDeviceIndex() == deviceIndex){
					this.listEdges.get(j).getSender().setBSTmark(true);
				}
			}
	}
	
	
	public void clearIntraGroupGraph(){
		for(int i=0;i<this.listEdges.size();i++){
			this.listEdges.get(i).deleteEdgeIntraGroup();
		}
			this.listEdges.clear();
			this.orderDeviceIndexes.clear();
			this.deviceIndexRoot=0;
			//this.groupLabel=null;
	}



}

