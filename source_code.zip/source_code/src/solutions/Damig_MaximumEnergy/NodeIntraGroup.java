package solutions.Damig_MaximumEnergy;

public class NodeIntraGroup {
	private int deviceIndex;
	private int component=0; // the component id is useful for MST algorithm
	private boolean BSTmark=false;
    private int DODAGrank=0;
    private boolean rankUpdated=false;

    
	public boolean getRankUpdated() {
		return rankUpdated;
	}
	
	public void setRankUpdated(boolean rankUpdated) {
		this.rankUpdated = rankUpdated;
	}
	
	
	public int getRank() {
		return DODAGrank;
	}
	public void setDODAGRank(int DODAGrank) {
		this.DODAGrank = DODAGrank;
	}
	
	public boolean isBSTmark() {
		return BSTmark;
	}
	public void setBSTmark(boolean bSTmark) {
		BSTmark = bSTmark;
	}
	public int getDeviceIndex() {
		return deviceIndex;
	}
	public void setDeviceIndex(int deviceIndex) {
		this.deviceIndex = deviceIndex;
	}
	public int getComponent() {
		return component;
	}
	public void setComponent(int component) {
		this.component = component;
	}


}
