package solutions.Damig_ShortestPathTree;

import java.util.ArrayList;
import java.util.List;

public class EdgeIntraGroup {
	
	// private int sender; // Store the index of the device
	// private int receiver; // Store the index of the device
	private NodeIntraGroup n1IntraGroup;
	private NodeIntraGroup n2IntraGroup;
	private int amountData = 1;
	private double weight;
	private boolean selectedForMST=false;
	
	


	public int getAmountData() {
		return amountData;
	}

	public void incrementAmountData(int increment) {
		this.amountData = increment;
	}

	public NodeIntraGroup getSender() {
		return n1IntraGroup;
	}
	
	public void setSender(int deviceIndex) {
		NodeIntraGroup n = new NodeIntraGroup();
		n.setDeviceIndex(deviceIndex);
		this.n1IntraGroup = n;
	}
	
	public NodeIntraGroup getReceiver() {
		return n2IntraGroup;
	}
	
	public void setReceiver(int deviceIndex) {
		NodeIntraGroup n = new NodeIntraGroup();
		n.setDeviceIndex(deviceIndex);
		this.n2IntraGroup = n;
	}
	
	public double getWeight() {
		return weight;
	}
	public void setWeight(double weight) {
		this.weight = weight;
	}

	public boolean isSelectedForMST() {
		return selectedForMST;
	}
	public void setSelectedForMST(boolean selectedForMST) {
		this.selectedForMST = selectedForMST;
	}
	
	
	public void changeRcvSdr(){

		NodeIntraGroup n = this.n1IntraGroup;		
		
		this.n1IntraGroup = this.n2IntraGroup;
		this.n2IntraGroup = n;
	}
	
	public void deleteEdgeIntraGroup(){
		this.n1IntraGroup=null;
		this.n2IntraGroup=null;
	}
	

}
