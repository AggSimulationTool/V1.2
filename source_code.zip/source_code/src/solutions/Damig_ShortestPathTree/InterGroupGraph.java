package solutions.Damig_ShortestPathTree;

import java.util.ArrayList;
import java.util.List;

public class InterGroupGraph {

	private String ID;
	private List<String> orderGroupLabels = new ArrayList<String>();
	private List<EdgeInterGroup> listEdges = new ArrayList<EdgeInterGroup>();

	
	


	public List<EdgeInterGroup> getListEdges() {
		return listEdges;
	}
	
	public void addEdge(int receiverDeviceIndex, int senderDeviceIndex, String receiverGroupLabel, String senderGroupLabel, double weight, List<Integer> deviceIndexesSP){
		EdgeInterGroup e = new EdgeInterGroup();
		e.setReceiver(receiverDeviceIndex, receiverGroupLabel);
		e.setSender(senderDeviceIndex, senderGroupLabel);
		e.setWeight(weight);
		e.setDeviceIndexesSP(deviceIndexesSP);
		
		this.listEdges.add(e);
	}


	
	
	public void computeSPT(String groupRootLabel){
		List<String> visitedGroups = new ArrayList<String>(); //It stores the selected groups
		List<String> unvisitedGroups = new ArrayList<String>(); //It stores the unvisited Groups
		String tempGroup;
		int numberOfGroups;
		double minDis; 
		int minEdge=-1;
		String newVisitedGroup="";
		String anyVisited;
		
		visitedGroups.add(groupRootLabel); // Put the root in the set of visited groups
		
		// Put all other groups in the set of unvisited groups
		for(int i=0; i<this.listEdges.size(); i++){
			tempGroup=this.listEdges.get(i).getReceiver().getGroupLabel();
			if(unvisitedGroups.contains(tempGroup)==false && visitedGroups.contains(tempGroup)==false)
				unvisitedGroups.add(tempGroup);
			tempGroup=this.listEdges.get(i).getSender().getGroupLabel();
			if(unvisitedGroups.contains(tempGroup)==false && visitedGroups.contains(tempGroup)==false)
				unvisitedGroups.add(tempGroup);
		}
		
		numberOfGroups=unvisitedGroups.size();//Visited groups has only the GW
		//--System.out.println("\nNumber of groups "+ numberOfGroups);
		//--System.out.println("Groups in the unvisited set");
		for(int j=0; j<unvisitedGroups.size();j++){
			//--System.out.println(unvisitedGroups.get(j));
		}
		
		while(visitedGroups.size() <= numberOfGroups){
			//Compute the lengths of the paths to all nodes directly reachable from visited through a node in visited
			//Gw is the first visited group
			minDis=Double.MAX_VALUE;
			
			for(int v=0; v<visitedGroups.size();v++){
				anyVisited=visitedGroups.get(v);
				//--System.out.println("\nGroup already visited "+anyVisited);
				for(int e=0; e<this.listEdges.size();e++){
					if(this.getListEdges().get(e).getSender().getGroupLabel() == anyVisited && unvisitedGroups.contains(this.getListEdges().get(e).getReceiver().getGroupLabel())  && minDis>this.listEdges.get(e).getWeight() && this.listEdges.get(e).isSelectedForSPT()==false){
						minDis=this.listEdges.get(e).getWeight();//update minCost 
						minEdge=e;//get the edge index
						newVisitedGroup=this.getListEdges().get(e).getReceiver().getGroupLabel(); // The new group to be visited is the neighbour of the already visited
						//--System.out.println("1) New visited Group "+ newVisitedGroup +" Minimum weight is "+minDis);
					}
					else if(this.getListEdges().get(e).getReceiver().getGroupLabel() == anyVisited && unvisitedGroups.contains(this.getListEdges().get(e).getSender().getGroupLabel())  && minDis>this.listEdges.get(e).getWeight() && this.listEdges.get(e).isSelectedForSPT()==false){
						minDis=this.listEdges.get(e).getWeight();//update minCost
						minEdge=e;//get the edge index
						newVisitedGroup=this.getListEdges().get(e).getSender().getGroupLabel(); // The new group to be visited is the neighbour of the already visited
						//--System.out.println("2) New visited Group "+ newVisitedGroup +" Minimum weight is "+minDis);
					}
				}
			}
			visitedGroups.add(newVisitedGroup);
			unvisitedGroups.remove(newVisitedGroup);
			//--System.out.println("----------- New edge selected for SPT. Group "+this.listEdges.get(minEdge).getSender().getGroupLabel() + " to "+this.listEdges.get(minEdge).getReceiver().getGroupLabel()+" weight "+this.listEdges.get(minEdge).getWeight());
			this.listEdges.get(minEdge).setSelectedForSPT(true);
		}
			
		}

	
	public void changeComponent(int oldComponent, int newComponent){
		for(int i=0;i<this.listEdges.size();i++){
			if(this.listEdges.get(i).getSender().getMSTcomponent()==oldComponent)
				this.listEdges.get(i).getSender().setMSTcomponent(newComponent);
			
			if(this.listEdges.get(i).getReceiver().getMSTcomponent()==oldComponent)
				this.listEdges.get(i).getReceiver().setMSTcomponent(newComponent);
		}
	}
	
	// Change the group component matching a particular group label
	public void changeGroupComponent(String groupLabel, int newComponent){
		for(int i=0;i<this.listEdges.size();i++){
			if(this.listEdges.get(i).getSender().getGroupLabel().equals(groupLabel))
				this.listEdges.get(i).getSender().setMSTcomponent(newComponent);
			
			if(this.listEdges.get(i).getReceiver().getGroupLabel().equals(groupLabel))
				this.listEdges.get(i).getReceiver().setMSTcomponent(newComponent);
		}
	}
	
	// Order the edges in increasing order according to the weight
	public void orderListEdges(){
		  int lenD=this.listEdges.size();
		  EdgeInterGroup tmpEdge;
		  for(int i = 0;i<lenD;i++){
		    for(int j = (lenD-1);j>=(i+1);j--){
		      if(this.listEdges.get(j).getWeight()<this.listEdges.get(j-1).getWeight()){
		        tmpEdge = this.listEdges.get(j);
		        
		        this.listEdges.set(j, this.listEdges.get(j-1));
		        
		        this.listEdges.set(j-1, tmpEdge);
		      }
		    }
		  }
		}
	
	
	
	public void printInterGroupGraph(){
		int i;
		System.out.print("\nPrinting inter group graph\n");
		for(i=0;i<this.getListEdges().size();i++){
			if(this.listEdges.get(i).isSelectedForSPT())
			System.out.println(this.listEdges.get(i).getSender().getGroupLabel()+" - "+this.listEdges.get(i).getReceiver().getGroupLabel()+" weight "+this.getListEdges().get(i).getWeight());
		}
		
	}
	
	// It Computes the number of edges having an particular group label 
	public int countEdgesOnMST(String groupLabel){
		int countEdges=0;
		for(int i=0;i<this.listEdges.size();i++){
			if((this.listEdges.get(i).isSelectedForSPT() == true) && (this.listEdges.get(i).getReceiver().getGroupLabel() == groupLabel || this.listEdges.get(i).getSender().getGroupLabel() == groupLabel) ){
					countEdges++;
				}
			}
		return countEdges;
	}

	//It Computes Breath First Search Order 
	public void BFS(String root){
		List<String> Q = new ArrayList();
		String v, w;
		
		Q.add(root);
		//--System.out.println("\n\n\nBreath First Search Order: ");
		this.markMSTnode(root);

		
		while(Q.isEmpty() == false){
			v=Q.get(0);
			Q.remove(0);
			//--System.out.print(v+" <- " );
			this.orderGroupLabels.add(v);
			for(int i=0;i<this.listEdges.size();i++){
				if(this.listEdges.get(i).isSelectedForSPT() == true && this.listEdges.get(i).getReceiver().getGroupLabel().equals(v)){
					w=this.listEdges.get(i).getSender().getGroupLabel();
					if(this.listEdges.get(i).getSender().isBSTmark() == false){
						this.markMSTnode(w);
						Q.add(w);
					}
				}
				else if (this.listEdges.get(i).isSelectedForSPT() == true && this.listEdges.get(i).getSender().getGroupLabel().equals(v)){
					w=this.listEdges.get(i).getReceiver().getGroupLabel();
					if(this.listEdges.get(i).getReceiver().isBSTmark() == false){
						this.markMSTnode(w);
						Q.add(w);
					}
				}
			}

		}
		
	}
	
	// All groups having this groupLabel will be marked as true 
	public void markMSTnode(String groupLabel){
			for(int j=0;j<this.listEdges.size();j++){
				if(this.listEdges.get(j).getReceiver().getGroupLabel().equals(groupLabel)){
					this.listEdges.get(j).getReceiver().setBSTmark(true);
				}
				if(this.listEdges.get(j).getSender().getGroupLabel().equals(groupLabel)){
					this.listEdges.get(j).getSender().setBSTmark(true);
				}
			}
	}
	
	
	// Update the number of messages
	public void increamentAmountData(String groupLabel, float amountData){
		for(int j=0;j<this.listEdges.size();j++){
			if(this.listEdges.get(j).getReceiver().getGroupLabel().equals(groupLabel))
				this.listEdges.get(j).getReceiver().incrementAmountData(amountData);
			if(this.listEdges.get(j).getSender().getGroupLabel().equals(groupLabel))
				this.listEdges.get(j).getSender().incrementAmountData(amountData);
		}
}
	
	// Compute the amount of data (number of messages) transmitted between the groups
	public void updateAmountData(){
		String groupLabel;
		//--System.out.println("\n\nAmount of Data Transmitted");
		
		for(int k=this.orderGroupLabels.size()-1;k>0;k--){
		groupLabel=this.orderGroupLabels.get(k);
		//--System.out.println("Group "+groupLabel);
		
			for(int j=0;j<this.listEdges.size();j++){
				if(this.listEdges.get(j).isSelectedForSPT()==true){
					if(this.listEdges.get(j).getReceiver().getGroupLabel().equals(groupLabel) && (this.listEdges.get(j).isTransmissionMark() == false )){
						this.increamentAmountData(this.listEdges.get(j).getSender().getGroupLabel(), this.listEdges.get(j).getReceiver().getAmountData());
						this.listEdges.get(j).setAmountDataEdge(this.listEdges.get(j).getReceiver().getAmountData());
						this.listEdges.get(j).setTransmissionMark(true);
						//--System.out.println(this.listEdges.get(j).getReceiver().getGroupLabel()+" transmit "+this.listEdges.get(j).getReceiver().getAmountData()+" message(s) to "+this.listEdges.get(j).getSender().getGroupLabel());
						this.listEdges.get(j).changeRcvSdr(); // Set the receiver as the sender and vice-versa. This is because before the MST and the BFS order, it is not possible to determine who is sender or receiver
						this.listEdges.get(j).invertOrderDevIndexSP();
					}
					else if(this.listEdges.get(j).getSender().getGroupLabel().equals(groupLabel) && (this.listEdges.get(j).isTransmissionMark() == false )){
						this.increamentAmountData(this.listEdges.get(j).getReceiver().getGroupLabel(), this.listEdges.get(j).getSender().getAmountData());
						this.listEdges.get(j).setAmountDataEdge(this.listEdges.get(j).getSender().getAmountData());
						this.listEdges.get(j).setTransmissionMark(true);
						//--System.out.println(this.listEdges.get(j).getSender().getGroupLabel()+" transmit "+this.listEdges.get(j).getSender().getAmountData()+ " message(s) to " +this.listEdges.get(j).getReceiver().getGroupLabel());
					}
				}
		
			}
		
		}
		
	}
	
	
	//Put the edges the selected MST edges before the non selected and in BFS Order
	public void bfsEdgeMSTinterGroup(){
		String groupLabel;
		EdgeInterGroup edgeTemp;
	
		//--System.out.println();
		
		for(int j=this.orderGroupLabels.size()-1;j>0;j--){
			groupLabel= this.orderGroupLabels.get(j);
	
			for(int i=0; i<this.listEdges.size();i++){
				if(this.listEdges.get(i).isSelectedForSPT() == true && this.listEdges.get(i).getSender().getGroupLabel().equals(groupLabel)){
					//--System.out.println(this.listEdges.get(i).getSender().getGroupLabel() + " device index " + this.listEdges.get(i).getSender().getSenderDeviceIndex() + " ---> " + this.listEdges.get(i).getReceiver().getGroupLabel()+" device index "+this.listEdges.get(i).getReceiver().getReceiverDeviceIndex());
					edgeTemp=this.listEdges.get(i);
					this.listEdges.remove(i);
					this.listEdges.add(0, edgeTemp);
				}
			}
		}
	
	}
	
	public int getSenderIndexOnMST(String groupLabel){
		int deviceIndex=-1;
		
		for(int i=0;i<this.listEdges.size();i++){
			if(this.listEdges.get(i).isSelectedForSPT() == true && this.listEdges.get(i).getSender().getGroupLabel().equals(groupLabel))
				deviceIndex=this.listEdges.get(i).getSender().getSenderDeviceIndex();
		}
		return deviceIndex;
	}
	
	public float findAmountData(String groupLabel){
		float amountData=1;
		for(int i=0; i<this.getListEdges().size();i++){
			if(this.getListEdges().get(i).isSelectedForSPT() == true){
				if(this.getListEdges().get(i).getSender().getGroupLabel() == groupLabel)
					amountData = this.getListEdges().get(i).getSender().getAmountData();
			}
		}
		return amountData;
	}
	
	
	public void deleteInterGroupGraph(){
		this.ID=null;
		for(int i=0;i<this.listEdges.size();i++){
			this.listEdges.get(i).deleteEdgeInterGroup();
		}
			this.listEdges.clear();
	}
	
	

}




