package solutions.NoInterGroupAggregation;
import java.util.ArrayList;
import java.util.List;

import code.Network;


public class EERS {

	
	
	private Network s3;
	private double[][] weightedGraph;
	private InterGroupGraph intergg = new InterGroupGraph();
	private List<IntraGroupGraph> intragg = new ArrayList();
	private double[] residualEnergy; // The device index is the index of array
	private int communicationRound=0;
	private boolean conectivity = true;
	private double sumIntraEnergy=0;
	private double sumInterEnergy=0;

	public void simulation(){
		boolean anyNodeDead=false;
	 	this.s3.setTime(1);
 		this.initializeResidualEnergy();

//		this.printWeightedGraph();
		  
		  
		while(anyNodeDead != true && this.conectivity==true){
		//for(int i=0;i<10;i++){		


			this.initializeWeightedGraph();
			communicationRound++;
			this.s3.findCommunicatingGroups();
			this.setInterGroupGraph();
			this.intergg.computeMST();
			this.countRxInterMST();
			this.intergg.BFS(this.s3.getGatewayLabelGroup());
			this.intergg.updateAmountData();
			this.intergg.bfsEdgeMSTinterGroup(); 
			//this.intergg.printInterGroupGraph();
			this.setIntraGroupGraph();
			this.computeAllIntraGroupGraphMST();
		  
			if(communicationRound==1)
				this.conectivity=this.MSTconectivityTest();// test to see if the selected MST edges of a group is a connected graph. This test is necessary once, since the intra graph does not change
		  

			this.setIntraRoot();
			this.computeBFSintraGroupOrder();
		 	if(communicationRound==1){
		 		this.conectivity=this.finalConnectivityTest(); // test to see if every device of a group belong to the MST. This test is necessary once, since the intra graph does not change
		 	}
		 	
		 		System.out.println("\n\n\n\n\n\n=============================  ROUND NUMBER "+communicationRound+" =============================");	
		 		this.printEnergy();
				
		 	this.deductIntraGroupEnergy();
		 	this.deductSPenergy();
		 	anyNodeDead = this.isAnyDeviceDead(communicationRound);
		 	this.s3.incrementTime();
		  
 
		 	//In each time instant, the objects and variables should be cleared
		 	this.s3.clearCommunicatingGroups();
		 	this.intergg.deleteInterGroupGraph();
		 	this.clearAllIntraGroupGraph();
		 	System.gc();
		}	
	}
	
	public void setNetwork(Network N){
		this.s3=N;
	}
	
	public int getCommunicationRounds(){
		return this.communicationRound;
	}
	
	public double getResidualEnergy(int index){
		return this.residualEnergy[index];
	}
	
	
	public double getAvgResidualEnergy(){
		double avgEnergy;
		double sum=0;
		for(int i=0; i<this.residualEnergy.length;i++){
			if(i != this.s3.getGatewayIndex())
			sum=sum + this.residualEnergy[i];
		}
		avgEnergy=sum/(this.residualEnergy.length -1);
		return avgEnergy;
	}
	
	public double getSumIntraEnergy(){
		return this.sumIntraEnergy;
	}
	
	public double getSumInterEnergy(){
		return this.sumInterEnergy;
	}
		
	public void initializeWeightedGraph(){
		boolean linkMatrix [][];
		linkMatrix=s3.getLinkMatrix();		
		this.weightedGraph =new double[linkMatrix.length][linkMatrix.length];
		float distance;
		float n1X, n1Y, n2X, n2Y;
		
		for(int i=0;i<this.weightedGraph.length;i++){
			for(int j=i;j<this.weightedGraph.length;j++){
				if(linkMatrix[i][j]){					
					distance = this.s3.findDistance(i, j);					
					// the matrix is symmetric
					//System.out.println("Rx "+(float)this.computeEnergyRx(distance, 1));
					this.weightedGraph[i][j]=(this.computeEnergyTx(distance, 1) + (this.computeEnergyRx(distance, 1)) / (this.residualEnergy[i]) + (this.residualEnergy[j]));
					this.weightedGraph[j][i]=(this.computeEnergyTx(distance, 1) + (this.computeEnergyRx(distance, 1)) / (this.residualEnergy[i]) + (this.residualEnergy[j]));
					//this.weightedGraph[i][j]=distance;
					//this.weightedGraph[j][i]=distance;
				}
				else{
					// -1 indicates that there is no link between the nodes
					this.weightedGraph[i][j]=-1;
					this.weightedGraph[j][i]=-1;
				}
			}
		}
	}
	
	public void printWeightedGraph(){
		System.out.print("\n\nPrinting weighted graph");
		for (int i=0;i<this.weightedGraph.length;i++){
			System.out.println();
			for(int j=0;j<this.weightedGraph.length;j++)
				System.out.print(this.weightedGraph[i][j]+" ");
		}
	}
		
	public void updateWeightedGraph(){
		
	}

	public boolean isAnyDeviceDead(int round){
		for(int i=0;i<this.residualEnergy.length;i++){
			if(this.residualEnergy[i]<0){
				System.out.println("\n\n\n ==================== END! ==================== ");
				System.out.println("Device "+i+", Energy "+this.residualEnergy[i]+" round "+round);
				return true;
			}
		}
		return false;
	}
	
	public void printEnergy(){
		System.out.print("\n");
		for(int i=0;i<this.residualEnergy.length;i++){
			System.out.println("Device "+i+" energy "+this.residualEnergy[i]);
		}
	}
	
	public void setInterGroupGraph(){
		//Default is 1
		int numOfGateways=1;
		String GWlabel;		
		String groupSender, groupReceiver;
		String Rcv, Sdr;
		float pathCost;
		
		//--System.out.println();
		// In this solutions the inter group edges are: Group X - GW
		GWlabel = this.s3.getGatewayLabelGroup();
		for(int i=0; i<this.s3.getSizeCommunicatingGroups();i++){
			if(this.s3.getCommunicatingGroups(i)!=GWlabel){
				// Find the Sender and Receiver of every Inter Group Graph edge
				groupSender=this.s3.getCommunicatingGroups(i);
				
				groupReceiver=GWlabel;
				
				//--System.out.println("\nComputing "+groupSender+"->"+groupReceiver);
				Rcv=this.selectReceiver(groupSender, groupReceiver);
				
				// Select an receiver node in the receiver group
				Sdr=this.selectReceiver(groupReceiver, groupSender);
				
				//--System.out.println("SP between "+Sdr+" and "+Rcv);
				// dijstra's parameters is index and not label
				this.dijstra(this.s3.findIndexDevice(Sdr), this.s3.findIndexDevice(Rcv), groupReceiver, groupSender);
			}
		}
	}
	
	// Compute the shortest path between the sender index and receiver index
	public void dijstra(int senderIndex, int receiverIndex, String groupReceiver, String groupSender){
		double [] distanceSdrRcv =new double [this.weightedGraph.length];
		List<Integer> selectedNodesIndexes = new ArrayList<Integer>();
		List<Integer> unvisitedNodesIndexes = new ArrayList<Integer>();
		double MinDis;
		int MinDisIndex=senderIndex;
		double updateDistance=0;
		double highValue=Double.MAX_VALUE;
		double sumCost=0;
		int test=0;
		for(int i=0;i<this.weightedGraph.length;i++){
			
			// Set a very high value to all nodes
			distanceSdrRcv[i]=highValue;
			//Add all nodes indexes in unvisited list
			unvisitedNodesIndexes.add(i);
			//System.out.println("Unvisited added " + i);
		}
		
		// Distance from source to source
		distanceSdrRcv[senderIndex]=0;

		
		while(unvisitedNodesIndexes.isEmpty() == false){
			MinDis=highValue;
			// Find the node index with min distance 
			for(int i=0;i<unvisitedNodesIndexes.size();i++){
				if(MinDis>distanceSdrRcv[unvisitedNodesIndexes.get(i)]){
					MinDis=distanceSdrRcv[unvisitedNodesIndexes.get(i)];
					MinDisIndex=unvisitedNodesIndexes.get(i);
					test=i;
				}
			}
			//System.out.println("Min distance node selected "+this.s2.getDevice(MinDisIndex).getLabel());
			
			
			// End
			if(MinDisIndex==receiverIndex){
				selectedNodesIndexes.add(MinDisIndex);
				break;
			}
			
			
			//System.out.println("MinDisIndex "+ MinDisIndex );
			//System.out.println("Size of Univisited Nodes Indexes "+unvisitedNodesIndexes);
			//Remove the min node index from unvisited
			unvisitedNodesIndexes.remove(test);
			
			// all remaining vertices are inaccessible from source
			if(distanceSdrRcv[MinDisIndex]==highValue)
				break;
			
			//for each neighbor of MinDisIndex
			for(int i=0;i<this.weightedGraph.length;i++){
				//Condition for i be neighbor of MinDisIndex
				if((this.weightedGraph[MinDisIndex][i]>= 0) && (unvisitedNodesIndexes.contains(i))){
					//--System.out.println("Neighbor of "+this.s1.getDevice(MinDisIndex).getLabel()+" is "+this.s1.getDevice(i).getLabel());
					//--System.out.println("dist["+this.s1.getDevice(i).getLabel()+"] "+distanceSdrRcv[i]);

					updateDistance=distanceSdrRcv[MinDisIndex]+this.weightedGraph[MinDisIndex][i];
					//--System.out.println("Update distance "+updateDistance);
					if(updateDistance<distanceSdrRcv[i]){
						//System.out.println("Teste");
						distanceSdrRcv[i]=updateDistance;
						if(!selectedNodesIndexes.contains(MinDisIndex)){
							selectedNodesIndexes.add(MinDisIndex);
						}
					}
				}
			}
	}
		//--System.out.println("Selected nodes ");
		for(int i=0;i<selectedNodesIndexes.size();i++){
			//--System.out.print(this.s2.getDevice(selectedNodesIndexes.get(i)).getLabel()+" ");
			sumCost=sumCost+distanceSdrRcv[selectedNodesIndexes.get(i)];
		}
		//--System.out.println("\nDistance: "+sumCost);
		this.intergg.addEdge(receiverIndex, senderIndex, groupReceiver, groupSender, sumCost, selectedNodesIndexes);

}
	
    // Select the node to be the Inter Receiver
	public String selectReceiver(String groupSender, String groupReceiver){
		String labelReceiver=null;
		List<String>nodesOfGroupSender = new ArrayList();
		List<String>nodesOfGroupReceiver = new ArrayList();
		int receiverIndex, senderIndex;
		double cost=0, costAux=0;
		float [] receiverCoord=new float [2];
		float [] senderCoord=new float [2];
		// To compute the best sender-receiver pair is necessary to choose one node 
		// located in the sender group and compute the distance of this nodes and all nodes in the receiver group. 
		nodesOfGroupSender=this.s3.findDevicesOfGroup(groupSender);
		nodesOfGroupReceiver=this.s3.findDevicesOfGroup(groupReceiver);
		
		// Pick any node in the sender group. In this case, it is the first one
		senderIndex=this.s3.findIndexDevice(nodesOfGroupSender.get(0));
		
		senderCoord[0]=this.s3.getDevice(senderIndex).getCoordX();
		senderCoord[1]=this.s3.getDevice(senderIndex).getCoordY();
		
		//  i is the index for nodes belonging to the receiver group
		for(int i=0;i<nodesOfGroupReceiver.size();i++){
			// compute the coordenates of the receiver
			receiverIndex = this.s3.findIndexDevice(nodesOfGroupReceiver.get(i));
			receiverCoord[0] = this.s3.getDevice(receiverIndex).getCoordX();
			receiverCoord[1] = this.s3.getDevice(receiverIndex).getCoordY();


			// First iteraction
			if(i==0){
				cost=(1 / this.residualEnergy[receiverIndex]);
				//cost=(Math.sqrt(Math.pow((receiverCoord[0]-senderCoord[0]),2)+Math.pow((receiverCoord[1]-senderCoord[1]),2) / this.residualEnergy[receiverIndex]));
				//cost=Math.sqrt(Math.pow((receiverCoord[0]-senderCoord[0]),2)+Math.pow((receiverCoord[1]-senderCoord[1]),2));
				labelReceiver=nodesOfGroupReceiver.get(i);
			}
			// Other iteractions
				costAux= (1/ this.residualEnergy[receiverIndex]);
				//costAux= (Math.sqrt(Math.pow((receiverCoord[0]-senderCoord[0]),2)+Math.pow((receiverCoord[1]-senderCoord[1]),2) / this.residualEnergy[receiverIndex] ));
				//costAux= Math.sqrt(Math.pow((receiverCoord[0]-senderCoord[0]),2)+Math.pow((receiverCoord[1]-senderCoord[1]),2) );
				// System.out.println("Distance between "+ nodesOfGroupReceiver.get(i) + " and " + nodesOfGroupSender.get(0)+ " is " +costAux);
				if(costAux<cost){
					cost=costAux;
					//Find the minimum receiver
					labelReceiver=nodesOfGroupReceiver.get(i);
				}
			
		}
		
		nodesOfGroupSender= null;
		nodesOfGroupReceiver = null;
		receiverCoord = null;
		senderCoord = null;
		
		
		//System.out.println("Receiver for group "+groupSender+" is "+labelReceiver);
		return labelReceiver;
	}
	
	public void setIntraGroupGraph(){
		List<String> devicesOfGroup = new ArrayList();
		int indexDevice;
		//--System.out.println("\n");
		
		for(int i=0;i<this.s3.getSizeCommunicatingGroups();i++){
			IntraGroupGraph intraGG = new IntraGroupGraph();
			//--System.out.print("\nCreating the intra group graph "+ this.s1.getCommunicatingGroups(i));
			
			// Create and add a new intra group graph for each communicating group
			intraGG.setGroupLabel(this.s3.getCommunicatingGroups(i));
			// find the nodes that belong to that group
			devicesOfGroup = this.s3.findDevicesOfGroup(this.s3.getCommunicatingGroups(i));
			// look for edges in weighted graph
				for(int j=0;j<this.weightedGraph.length;j++){
					for(int k=j+1;k<this.weightedGraph.length;k++){
						if(this.weightedGraph[j][k] != -1 && (devicesOfGroup.contains(this.s3.getDevice(j).getLabel()) && devicesOfGroup.contains(this.s3.getDevice(k).getLabel()))){
							intraGG.addEdge(j, k, this.weightedGraph[j][k]);
							//--System.out.println("New edge added. Sender "+ this.s1.getDevice(j).getLabel() +" Receiver " + this.s1.getDevice(k).getLabel() + " weight " + this.weightedGraph[j][k]);
						}
					}
				}
			this.intragg.add(intraGG);
		}
		devicesOfGroup=null;
	}
		
	public void computeAllIntraGroupGraphMST(){
		for(int i=0;i<this.intragg.size();i++){
			this.intragg.get(i).computeMST();
		}
	}

	public boolean MSTconectivityTest(){
		boolean conect=true;
		
		System.out.print("\n\nTest of connectivity of each Inter Group Graph:");
		
		for(int i=0;i<this.intragg.size();i++){
			if(this.intragg.get(i).connectedTest()==false){
				System.out.println("\n\n\n\nGroup "+this.intragg.get(i).getGroupLabel()+ " did not form a connected graph");
				System.out.println("Stopping the execution");
				conect=false;
			}
		}	
		return conect;
	}
	
	public void countRxInterMST(){
		String groupLabel;
		int nEdges;
		//--System.out.print("\n\nThe number of childs of each Inter Group Graph Node:");
		for(int i=0;i<this.s3.getSizeCommunicatingGroups();i++){
			groupLabel=this.s3.getCommunicatingGroups(i);
			nEdges=this.intergg.countEdgesOnMST(groupLabel);
			if(groupLabel != this.s3.getGatewayLabelGroup())
				nEdges=nEdges-1;
				//--System.out.print("\nChids of group "+groupLabel+" is "+nEdges);
		}
		
	}
	
	public void setIntraRoot(){
		String groupLabel;
		int intraRootDeviceIndex;
		
		for(int i=0;i<this.intragg.size();i++){
			groupLabel=this.intragg.get(i).getGroupLabel();
			intraRootDeviceIndex=this.intergg.getSenderIndexOnMST(groupLabel);
			this.intragg.get(i).setDeviceIndexRoot(intraRootDeviceIndex);
		}
	}
	
	public void computeBFSintraGroupOrder(){
		for(int i=0;i<this.intragg.size();i++){
			if(this.intragg.get(i).getGroupLabel() != this.s3.getGatewayLabelGroup() )
			this.intragg.get(i).BFS();
		}
	}
	
	public boolean finalConnectivityTest(){
		boolean conect=true;
		System.out.print("\n\nFinal Test of connectivity for Intra Groups:");
		
		for(int i=0;i<this.intragg.size();i++){
			if((this.intragg.get(i).getGroupLabel() != this.s3.getGatewayLabelGroup() ) && (this.intragg.get(i).getOrderDeviceIndexes().size() != this.s3.findDevicesOfGroup(this.intragg.get(i).getGroupLabel()).size())){
				System.out.println("\n\n\n\nGroup "+this.intragg.get(i).getGroupLabel()+ " has a device not connected");
				System.out.println("Stopping the execution");
				conect=false;
			}
			else
				System.out.print("\nGroup "+this.intragg.get(i).getGroupLabel()+ " --- OK");
		}		
		return conect;
	}
	
	public void initializeResidualEnergy(){
		this.residualEnergy = new double [this.s3.getLinkMatrix().length];
		for(int i=0; i<this.s3.getLinkMatrix().length;i++){
			this.residualEnergy[i]=this.s3.getDevice(i).getInitialEnergy();
		}
	}
	
	public void deductIntraGroupEnergy(){
		String groupLabel;
		int deviceIndexSdr, deviceIndexRcv;
		double energyCostTx;
		double energyCostRx;
		float nMsgs;
		float distance;
		
		//--System.out.print("\n\n\nAll Intra Group TX and RX");
		
		for(int i=0;i<this.intragg.size();i++){ //do this for all groups
			groupLabel = this.intragg.get(i).getGroupLabel();
			//--System.out.print("\n\nGroup "+groupLabel);
			for(int j=0;j<this.intragg.get(i).getListEdges().size();j++){
				if(this.intragg.get(i).getListEdges().get(j).isSelectedForMST() == true ){
					deviceIndexSdr = this.intragg.get(i).getListEdges().get(j).getSender().getDeviceIndex();
					deviceIndexRcv = this.intragg.get(i).getListEdges().get(j).getReceiver().getDeviceIndex();
					distance = this.s3.findDistance(deviceIndexSdr, deviceIndexRcv);
					// TRANSMISSION
					// Find the number of messages
					nMsgs=this.intergg.findAmountData(groupLabel);
					// Find the energy cost for Tx
					energyCostTx = this.computeEnergyTx(distance, nMsgs);
					// Deducts the energy cost from the residual energy of sender
					this.residualEnergy[deviceIndexSdr] = this.residualEnergy[deviceIndexSdr] - energyCostTx;
					//--System.out.print("\nDevice "+deviceIndexSdr+" Tx to "+ deviceIndexRcv + " " + nMsgs + " msgs consuming " + energyCost);
					// RECEPTION
					// the number of messages is the same for all nodes inside the group
					// Find the energy cost for Rx
					energyCostRx = this.computeEnergyRx(distance, nMsgs);
					// Deducts the energy cost from the residual energy of receiver
					this.residualEnergy[deviceIndexRcv] = this.residualEnergy[deviceIndexRcv] - energyCostRx;
					//--System.out.print("\nDevice "+ deviceIndexRcv +" Rx from " + deviceIndexSdr + " " + nMsgs + " msgs consuming " + energyCost);
					this.sumIntraEnergy=this.sumIntraEnergy+energyCostTx+energyCostRx; 
				}
			}
		}
	}
	
	public void deductSPenergy(){
		List<Integer> listDevIndex;
		int deviceIndexSdr, deviceIndexRcv;
		float distance;
		float nMsgs;
		double energyCostTx;
		double energyCostRx;
		
		//--System.out.print("\n\n\nAll SP TX and RX");
		for(int i=0; i<this.intergg.getListEdges().size();i++){
			if(this.intergg.getListEdges().get(i).isSelectedForMST()){
				//--System.out.print("\n\nSP "+ this.intergg.getListEdges().get(i).getSender().getGroupLabel()+" --> "+ this.intergg.getListEdges().get(i).getReceiver().getGroupLabel());
				listDevIndex = this.intergg.getListEdges().get(i).getDeviceIndexesSP();
				for(int k=0;k+1<listDevIndex.size();k++){
						deviceIndexSdr=listDevIndex.get(k);// find the distance
						deviceIndexRcv=listDevIndex.get(k+1);
						distance = this.s3.findDistance(deviceIndexSdr, deviceIndexRcv);
						nMsgs = this.intergg.getListEdges().get(i).getAmountDataEdge();
						energyCostTx = this.computeEnergyTx(distance, nMsgs);
						this.residualEnergy[deviceIndexSdr] = this.residualEnergy[deviceIndexSdr] - energyCostTx;
						//--System.out.print("\nDevice "+deviceIndexSdr+" Tx to "+ deviceIndexRcv + " " + nMsgs + " msgs consuming " + energyCost);
						
						energyCostRx = this.computeEnergyRx(distance, nMsgs);
						this.residualEnergy[deviceIndexRcv] = this.residualEnergy[deviceIndexRcv] - energyCostRx;
						//--System.out.print("\nDevice "+deviceIndexRcv+" Rx from "+ deviceIndexSdr + " " + nMsgs + " msgs consuming " + energyCost);
						this.sumInterEnergy=this.sumInterEnergy+energyCostRx+energyCostTx; // count 1 header for each interGraph edge
				}
			}
		}
	}
	
	public double computeEnergyTx(float distance, float nMsgs){
		// Tx = nbits.50nJ/bit + nbits.100pJ/bit/m * distance^2
		double elec=50*(Math.pow(10, -9)); // Energy required to run the circuit 50nJ/bit
		double amp = 100*(Math.pow(10, -12)); // Energy required to tx
		float singleMsgLength = 4 * 8; // in bits
		float headerLength = 12 * 8; // in bits
		double nBits = headerLength + (singleMsgLength * nMsgs);
		//double turnonCost = 0.000022;//Cost to turn on the device and the radio (in Joules)
		double turnonCost = 0;//Set to zero to compare with the optimum
		double energyCost = (nBits*elec) + (nBits*amp*Math.pow(distance, 2))+turnonCost;
		
		return energyCost;
	}

	public double computeEnergyRx(float distance, float nMsgs){
		// Rx = nbits.50nJ/bit
		double elec=50*(Math.pow(10, -9)); // Energy required to run the circuit 50nJ/bit
		float singleMsgLength = 4 * 8; // in bits
		float headerLength = 12 * 8; // in bits
		double nBits = headerLength + (singleMsgLength * nMsgs);
		//double turnonCost = 0.000022;//Cost to turn on the device and the radio (in Joules)
		double turnonCost = 0;//Set to zero to compare with the optimum
		double energyCost = nBits*elec + turnonCost;
		
		return energyCost;
	}
	
	public void clearAllIntraGroupGraph(){
		for(int i=0;i<this.intragg.size();i++){
			this.intragg.get(i).clearIntraGroupGraph();
		}
		this.intragg.clear();

	}



	
}
