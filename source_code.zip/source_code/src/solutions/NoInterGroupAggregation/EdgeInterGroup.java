package solutions.NoInterGroupAggregation;

import java.util.ArrayList;
import java.util.List;

public class EdgeInterGroup {
	private double weight;
	private boolean selectedForMST=false;
	private NodeInterGroup sender;
	private NodeInterGroup receiver;
	private boolean transmissionMark=false;
	private float amountDataEdge;
	private List<Integer> deviceIndexesSP = new ArrayList();
	
	
	
	public List<Integer> getDeviceIndexesSP() {
		return deviceIndexesSP;
	}

	public void setDeviceIndexesSP(List<Integer> deviceIndexesSP) {
		this.deviceIndexesSP = deviceIndexesSP;
	}
	
	public void invertOrderDevIndexSP(){
		List<Integer> temp = new ArrayList();
		int size = this.deviceIndexesSP.size()-1;
		for(int i=size; i>0;i--){
			temp.add(this.deviceIndexesSP.get(i));
		}
		this.setDeviceIndexesSP(temp);
	}

	public float getAmountDataEdge() {
		return amountDataEdge;
	}

	public void setAmountDataEdge(float amountDataEdge) {
		this.amountDataEdge = amountDataEdge;
	}

	public boolean isTransmissionMark() {
		return transmissionMark;
	}

	public void setTransmissionMark(boolean transmissionMark) {
		this.transmissionMark = transmissionMark;
	}

	public NodeInterGroup getSender() {
		return sender;
	}

	public NodeInterGroup getReceiver() {
		return receiver;
	}

	public boolean isSelectedForMST() {
		return selectedForMST;
	}
	public void setSelectedForMST(boolean selectedForMST) {
		this.selectedForMST = selectedForMST;
	}

	public double getWeight() {
		return weight;
	}
	public void setWeight(double weight) {
		this.weight = weight;
	}

	public void setSender( int sdrDeviceIndex, String sdrGroupLabel){
		NodeInterGroup n = new NodeInterGroup();
		n.setSenderDeviceIndex(sdrDeviceIndex);
		n.setGroupLabel(sdrGroupLabel);
		this.sender=n;
	}
	
	public void setReceiver(int rcvDeviceIndex, String rcvGroupLabel){
		NodeInterGroup n = new NodeInterGroup();
		n.setReceiverDeviceIndex(rcvDeviceIndex);
		n.setGroupLabel(rcvGroupLabel);
		this.receiver=n;
	}
	
	public void changeRcvSdr(){

		NodeInterGroup n = this.receiver;		
		
		this.receiver = this.sender;
		this.sender = n;
		
		this.receiver.changeRcvSdrIndex();
		this.sender.changeRcvSdrIndex();
		
	}

	public void deleteEdgeInterGroup(){
		this.deviceIndexesSP.clear();;
		this.receiver=null;
		this.sender=null;
		this.amountDataEdge=0;
	}
	
	
	
	
	
}
