package solutions.NoInterGroupAggregation;

import java.util.ArrayList;
import java.util.List;

public class IntraGroupGraph {
	private String groupLabel;
	private List<EdgeIntraGroup> listEdges = new ArrayList<EdgeIntraGroup>();
	private int deviceIndexRoot;
	private List<Integer> orderDeviceIndexes = new ArrayList<Integer>();
	

	
	public List getOrderDeviceIndexes(){
		return this.orderDeviceIndexes;
		
	}
	
	public int get1OrderDeviceIndex(int deviceIndex){
		return this.orderDeviceIndexes.get(deviceIndex);
	}
	
	public int getDeviceIndexRoot() {
		return deviceIndexRoot;
	}


	public void setDeviceIndexRoot(int deviceIndexRoot) {
		this.deviceIndexRoot = deviceIndexRoot;
	}


	public String getGroupLabel(){
		return this.groupLabel;
	}


	public void setGroupLabel(String groupLabel) {
		this.groupLabel = groupLabel;
	}


	public List<EdgeIntraGroup> getListEdges() {
		return listEdges;
	}

	public void setListEdges(List<EdgeIntraGroup> listEdges) {
		this.listEdges = listEdges;
	}

	public void addEdge(int senderIndex, int receiverIndex, double weight){
		EdgeIntraGroup e = new EdgeIntraGroup();
		e.setSender(senderIndex);
		e.setReceiver(receiverIndex);
		e.setWeight(weight);
		
		this.listEdges.add(e);
	}
	
	
	public void computeMST(){
		boolean senderNoComponent, receiverNoComponent, testDiffComponent;
		int componentCounter=0;
		int changeComponentID;
		
		// Order the listEdge
		this.orderListEdges();
		//--System.out.println("\nComputing Intra Group Graph of "+this.getGroupLabel());
		
		for(int i=0;i<this.listEdges.size();i++){
			if(this.listEdges.get(i).getSender().getComponent()==0)
				senderNoComponent=true;
			else
				senderNoComponent=false;
			if(this.listEdges.get(i).getReceiver().getComponent()==0)
				receiverNoComponent=true;
			else
				receiverNoComponent=false;

			if(this.listEdges.get(i).getSender().getComponent() != this.listEdges.get(i).getReceiver().getComponent())
				testDiffComponent=true;
			else
				testDiffComponent=false;
				
							
				if((senderNoComponent||receiverNoComponent)||testDiffComponent){
					this.listEdges.get(i).setSelectedForMST(true); // mark the edge as selected
					//--System.out.println("\nEdge selected: "+this.listEdges.get(i).getSender().getDeviceIndex()+" - "+this.listEdges.get(i).getReceiver().getDeviceIndex()+"        Weight "+this.listEdges.get(i).getWeight());

					
					// If sender and receiver belong to any component
					if(senderNoComponent && receiverNoComponent){
						componentCounter++;
						this.changeDeviceComponent(this.listEdges.get(i).getSender().getDeviceIndex(), componentCounter);
						this.changeDeviceComponent(this.listEdges.get(i).getReceiver().getDeviceIndex(), componentCounter);
						//--System.out.println("All edges with device index "+ this.listEdges.get(i).getSender().getDeviceIndex()+" belongs to the new component "+ componentCounter);
						//--System.out.println("All edges with device index "+ this.listEdges.get(i).getReceiver().getDeviceIndex()+" belongs to the new component "+ componentCounter);
					}
				
					// If sender or receiver belong to a component
					else if(((!senderNoComponent) && (!receiverNoComponent)) && testDiffComponent){
						//--System.out.println("All device indexes from component "+this.listEdges.get(i).getReceiver().getComponent()+" now belongs to the component "+ this.listEdges.get(i).getSender().getComponent());
						this.changeComponent(this.listEdges.get(i).getReceiver().getComponent(), this.listEdges.get(i).getSender().getComponent());
					}
				
				
					if(senderNoComponent&&(!receiverNoComponent)){
						//--System.out.println("All edges with device index "+this.listEdges.get(i).getSender().getDeviceIndex()+" now belongs to the component "+ this.listEdges.get(i).getReceiver().getComponent());
						this.changeDeviceComponent(this.listEdges.get(i).getSender().getDeviceIndex(), this.listEdges.get(i).getReceiver().getComponent());
					}
					
					if(receiverNoComponent&&(!senderNoComponent)){
						//--System.out.println("All edges with device index "+ this.listEdges.get(i).getReceiver().getDeviceIndex()+" now belongs to the component "+ this.listEdges.get(i).getSender().getComponent());
						this.changeDeviceComponent(this.listEdges.get(i).getReceiver().getDeviceIndex(),this.listEdges.get(i).getSender().getComponent());
					}
				

				}
			}
		
		
	}

	
	public boolean connectedTest(){
		if(this.listEdges.isEmpty()==false){
			int component=this.listEdges.get(0).getSender().getComponent();
			System.out.print("\nTesting the connectivity of "+this.getGroupLabel());
			for (int i=0;i<this.listEdges.size();i++){
				if((this.listEdges.get(i).isSelectedForMST() == true) && (this.listEdges.get(i).getSender().getComponent() != component))
					return false;
				if((this.listEdges.get(i).isSelectedForMST() == true) && (this.listEdges.get(i).getReceiver().getComponent() != component))
					return false;
			}
			System.out.print(" --- OK");
			return true;
		}
		return true;
	}
	
	
	public void changeComponent(int oldComponent, int newComponent){
		for(int i=0;i<this.listEdges.size();i++){
			if(this.listEdges.get(i).getSender().getComponent()==oldComponent)
				this.listEdges.get(i).getSender().setComponent(newComponent);
			
			if(this.listEdges.get(i).getReceiver().getComponent()==oldComponent)
				this.listEdges.get(i).getReceiver().setComponent(newComponent);
		}
	}
	
	public void changeDeviceComponent(int deviceIndex, int newComponent){
		for(int i=0;i<this.listEdges.size();i++){
			if(this.listEdges.get(i).getReceiver().getDeviceIndex()==deviceIndex)
				this.listEdges.get(i).getReceiver().setComponent(newComponent);
			
			if(this.listEdges.get(i).getSender().getDeviceIndex()==deviceIndex)
				this.listEdges.get(i).getSender().setComponent(newComponent);
		}
	}
	
	// Put the edges in increase order of weight
	public void orderListEdges(){
		  int lenD=this.listEdges.size();
		  EdgeIntraGroup tmpEdge;
		  for(int i = 0;i<lenD;i++){
		    for(int j = (lenD-1);j>=(i+1);j--){
		      if(this.listEdges.get(j).getWeight()<this.listEdges.get(j-1).getWeight()){
		        tmpEdge = this.listEdges.get(j);
		        
		        this.listEdges.set(j, this.listEdges.get(j-1));
		        
		        this.listEdges.set(j-1, tmpEdge);
		      }
		    }
		  }
		}
	
	
	
	public int countEdgesOnMST(int deviceIndex){
		int countEdges=0;
		for(int i=0;i<this.listEdges.size();i++){
			if(this.listEdges.get(i).getReceiver().getDeviceIndex() == deviceIndex || this.listEdges.get(i).getSender().getDeviceIndex() == deviceIndex)
				countEdges++;
		}
	return countEdges;
	}
	
	
	//It Computes Breath First Search Order 
	public void BFS(){
		List<Integer> Q = new ArrayList();
		int v, w;
		
		// get the root of the intra group
		int root = this.deviceIndexRoot;
		
		
		Q.add(root);
		//--System.out.println("\n\n\nBreath First Search Order of Group "+this.groupLabel);
		this.markMSTnode(root);

		
		while(Q.isEmpty() == false){
			v=Q.get(0);
			Q.remove(0);
			//--System.out.print(v+" <- " );
			this.orderDeviceIndexes.add(v);
			for(int i=0;i<this.listEdges.size();i++){
				if(this.listEdges.get(i).isSelectedForMST() == true && this.listEdges.get(i).getReceiver().getDeviceIndex() == v){
					w=this.listEdges.get(i).getSender().getDeviceIndex();
					if(this.listEdges.get(i).getSender().isBSTmark() == false){
						this.markMSTnode(w);
						Q.add(w);
						//System.out.println("Receiver marked "+w);
					}
					this.listEdges.get(i).changeRcvSdr(); // because the v node must be always the receiver (the parent, not the child)
				}
				else if (this.listEdges.get(i).isSelectedForMST() == true && this.listEdges.get(i).getSender().getDeviceIndex() == v){
					w=this.listEdges.get(i).getReceiver().getDeviceIndex();
					if(this.listEdges.get(i).getReceiver().isBSTmark() == false){
						this.markMSTnode(w);
						Q.add(w);
						//System.out.println("Sender marked "+w);
					}

				}
			}

		}
		
	}
	
	
	// All groups having this groupLabel will be marked as true 
	public void markMSTnode(int deviceIndex){
			for(int j=0;j<this.listEdges.size();j++){
				if(this.listEdges.get(j).getReceiver().getDeviceIndex() == deviceIndex){
					this.listEdges.get(j).getReceiver().setBSTmark(true);
				}
				if(this.listEdges.get(j).getSender().getDeviceIndex() == deviceIndex){
					this.listEdges.get(j).getSender().setBSTmark(true);
				}
			}
	}
	
	
	public void clearIntraGroupGraph(){
		for(int i=0;i<this.listEdges.size();i++){
			this.listEdges.get(i).deleteEdgeIntraGroup();
		}
			this.listEdges.clear();
			this.orderDeviceIndexes.clear();
			this.deviceIndexRoot=0;
			this.groupLabel=null;
	}



}

