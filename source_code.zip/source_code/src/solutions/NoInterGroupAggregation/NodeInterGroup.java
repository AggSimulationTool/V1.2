package solutions.NoInterGroupAggregation;

public class NodeInterGroup {
	private int receiverDeviceIndex=-1;
	private int senderDeviceIndex=-1;
	private String groupLabel;
	private int MSTcomponent;
	private boolean BSTmark=false;
	private float amountDataGroup=1;

	

	public float getAmountData() {
		return amountDataGroup;
	}
	
	public void incrementAmountData(float amountData) {
		float amount=this.amountDataGroup; 
		
		this.amountDataGroup = amount + amountData;
	}
	
	public boolean isBSTmark() {
		return BSTmark;
	}
	public void setBSTmark(boolean bSTmark) {
		BSTmark = bSTmark;
	}
	
	public int getReceiverDeviceIndex() {
		return this.receiverDeviceIndex;
	}
	public int getSenderDeviceIndex() {
		return this.senderDeviceIndex;
	}
	public void setReceiverDeviceIndex(int index) {
		this.receiverDeviceIndex = index;
	}
	public void setSenderDeviceIndex(int index) {
		this.senderDeviceIndex = index;
	}
	
	public int getMSTcomponent() {
		return MSTcomponent;
	}
	public void setMSTcomponent(int mSTcomponent) {
		MSTcomponent = mSTcomponent;
	}
	
	
	public String getGroupLabel() {
		return groupLabel;
	}
	public void setGroupLabel(String groupLabel) {
		this.groupLabel = groupLabel;
	}

	
	public void changeRcvSdrIndex(){

		int n = this.receiverDeviceIndex;		
		
		this.receiverDeviceIndex = this.senderDeviceIndex;
		this.senderDeviceIndex = n;
		
	}
	
	
}
