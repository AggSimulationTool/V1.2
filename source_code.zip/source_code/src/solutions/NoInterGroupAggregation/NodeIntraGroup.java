package solutions.NoInterGroupAggregation;

public class NodeIntraGroup {
	private int deviceIndex;
	private int component=0;
	private boolean BSTmark=false;
	
	
	
	public boolean isBSTmark() {
		return BSTmark;
	}
	public void setBSTmark(boolean bSTmark) {
		BSTmark = bSTmark;
	}
	public int getDeviceIndex() {
		return deviceIndex;
	}
	public void setDeviceIndex(int deviceIndex) {
		this.deviceIndex = deviceIndex;
	}
	public int getComponent() {
		return component;
	}
	public void setComponent(int component) {
		this.component = component;
	}
	
	

}
