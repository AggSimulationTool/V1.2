/*
The Damig Link Cost 1 = Etxi+Etxj/REi+REj 
TTAMA is different than DAMiG. TTAMA uses an heuristic for the Steiner Tree Problem. 
This heuristic computes an MST for all network and prune the nodes that are used in each communication round.
*/
package solutions.ttama;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import code.Network;



public class TTAMA{

	private Network s5;
	private double[][] weightedGraph;
	private boolean[][] steinerTree;
	private double [][] msgs;
	private double[] residualEnergy; // The device index is the index of array
	private int communicationRound=0;
	private boolean conectivity = true;
	private double sumIntraEnergy=0;
	private double sumInterEnergy=0;

	
	public void simulation(){

		boolean anyNodeDead=false;
		this.s5.setTime(1);
	 	this.initializeResidualEnergy();
	 	//--------------------- Add some method to test the connectivy of the groups
	 	

//		  this.printWeightedGraph();
		
		while(anyNodeDead != true && this.conectivity == true){
		//for(int i=0;i<10;i++){
			this.initializeWeightedGraph();
			communicationRound++;
			this.s5.findCommunicatingGroups();
			//this.printWeightedGraph();
			this.computeSteinerTree(); 
			this.amountDatainSteinerTree();
			//this.printMsgSteinerTree();
			this.deductEnergy();			

			System.out.println("\n\n\n\n\n\n=============================  ROUND NUMBER "+communicationRound+" =============================");	
				this.printEnergy();
				
			 anyNodeDead = this.isAnyDeviceDead(communicationRound);		 
			 this.s5.incrementTime();
			 this.s5.clearCommunicatingGroups();
		}	
	}
	
	
	public void initializeResidualEnergy(){
		this.residualEnergy = new double [this.s5.getLinkMatrix().length];
		for(int i=0; i<this.s5.getLinkMatrix().length;i++){
			this.residualEnergy[i]=this.s5.getDevice(i).getInitialEnergy();
		}
	}
	

	public void setNetwork(Network N){
		this.s5=N;
	}
	
	public int getCommunicationRounds(){
		return this.communicationRound;
	}
	
	public double getResidualEnergy(int index){
		return this.residualEnergy[index];
	}
	
	public double getAvgResidualEnergy(){
		double avgEnergy;
		double sum=0;
		for(int i=0; i<this.residualEnergy.length;i++){
			if(i != this.s5.getGatewayIndex())
			sum=sum + this.residualEnergy[i];
		}
		avgEnergy=sum/(this.residualEnergy.length -1);
		return avgEnergy;
	}
	
	public double getSumIntraEnergy(){
		return this.sumIntraEnergy;
	}
	
	public double getSumInterEnergy(){
		return this.sumInterEnergy;
	}
	
	public boolean isAnyDeviceDead(int round){
		for(int i=0;i<this.residualEnergy.length;i++){
			if(this.residualEnergy[i]<0){
				System.out.println("\n\n\n ==================== END! ==================== ");
				System.out.println("Device "+i+", Energy "+this.residualEnergy[i]+" round "+round);
				return true;
			}
		}
		return false;
	}
	
	public void printEnergy(){
		System.out.print("\n");
		for(int i=0;i<this.residualEnergy.length;i++){
			System.out.println("Device "+i+" energy "+this.residualEnergy[i]);
		}
	}
	


		
	// Compute the weights and assign to the Matrix which represents the graph
	public void initializeWeightedGraph(){
		boolean linkMatrix [][];
		linkMatrix=s5.getLinkMatrix();		
		this.weightedGraph =new double[linkMatrix.length][linkMatrix.length];
		float distance;
		float n1X, n1Y, n2X, n2Y;
		
		for(int i=0;i<this.weightedGraph.length;i++){
			for(int j=i;j<this.weightedGraph.length;j++){
				if(linkMatrix[i][j]){					
					distance = this.s5.findDistance(i, j);					
					// the matrix is symmetric
					//System.out.println("Rx "+(float)this.computeEnergyRx(distance, 1));
					this.weightedGraph[i][j]=(this.computeEnergyTx(distance, 1) + (this.computeEnergyRx(distance, 1)) / (this.residualEnergy[i]) + (this.residualEnergy[j]));
					this.weightedGraph[j][i]=(this.computeEnergyTx(distance, 1) + (this.computeEnergyRx(distance, 1)) / (this.residualEnergy[i]) + (this.residualEnergy[j]));
					//this.weightedGraph[i][j]=distance;
					//this.weightedGraph[j][i]=distance;
				}
				else{
					// -1 indicates that there is no link between the nodes
					this.weightedGraph[i][j]=-1;
					this.weightedGraph[j][i]=-1;
				}
			}
		}
	}

	
	
	

	// Compute the Steiner Tree for all nodes of the network
	// The input is the WeightedGraph
	// The output is an matrix where each node has a single parent
	// the Steiner Tree Matrix should represent an directed graph. So, steinerTree[i][j] is dff of steinerTree[j][i].
	// steinerTree[i][j] means the edge from i to j and the steinerTree[j][i] means the edge from j to i.
	// If i has an edge to j means that i is a child of j, and j is its parent.
	public void computeSteinerTree(){
		// ==================== Variables ================================
		
		//Initialize steinerTree matrix with the same size of the weighted graph
		this.steinerTree=new boolean[this.weightedGraph.length][this.weightedGraph.length];		
		// Store the node index that were not visited by the MST algorithm
		List<Integer> coveredIndexes = new ArrayList();
		// Store the visited nodes
		List<Integer>  uncoveredIndexes = new ArrayList();
		// Store the uncovered and neighbour  node with minimum edge weight
		int selectedUncovered=0;
		int selectedCovered=0;
		
		int coverIndex;
		Double minEdgeWeight;
		double edgeWeight;
		
	// ================= Find the MST for weighted graph ====================
		// Put all nodes in uncoveredIndexes. The index Zero is the GW index
		for (int i=1;i<this.steinerTree.length;i++)
			uncoveredIndexes.add(i);
		
		// Put the Gw as covered
		coveredIndexes.add(0);
		
		while(uncoveredIndexes.size() != 0){
		//for(int h=0;h<1;h++){
			//System.out.println("\n\n\n Beginning");
			
			minEdgeWeight=Double.MAX_VALUE;
			edgeWeight=0;
			// 1 - Find the neighbour Indexes
			for (int i=0;i<coveredIndexes.size();i++){ // all covered nodes
				coverIndex = coveredIndexes.get(i);
				//System.out.println("i="+i);
				for (int j=0;j<this.weightedGraph.length;j++){ 
					//System.out.println("j="+j);
					if((this.weightedGraph[coverIndex][j] != -1) && (uncoveredIndexes.contains(j)) ){ // all neighbours of i node that are uncovered
						//System.out.println("Neighbours of "+ coverIndex + " are " + j);
						if(this.weightedGraph[coverIndex][j] < minEdgeWeight){ // if this neighbour and uncovered node has the minimum edge weight, so it should be included in the MST.
							minEdgeWeight= this.weightedGraph[coverIndex][j];
							selectedUncovered=j;
							selectedCovered=coverIndex;
							//System.out.println("min edge is "+ minEdgeWeight);
						}
					}
				}
			}
			
			//Include in the tree
			//System.out.println("The selected uncovered node is "+ selectedUncovered);
			//System.out.println("The selected covered node is "+ selectedCovered);
			
			this.steinerTree[selectedCovered][selectedUncovered]=true;//In this matrix, supporsing the parent of a node i is j, it is accessed steinerTree[j][i]. The childs of i are accessed as steinerTree[i][j]
			
	        // Update the cover and uncovered nodes
			uncoveredIndexes.remove(uncoveredIndexes.indexOf(selectedUncovered));
			coveredIndexes.add(selectedUncovered);
			//System.out.println("Uncovered list " + uncoveredIndexes.size());
			//System.out.println("New Covered Node "+ coveredIndexes.get(coveredIndexes.indexOf(selectedUncovered)));
			
			
		}
		
	}	
	
	
	public void printSteinerTree(){
		for(int i=0;i<this.steinerTree.length;i++){
			System.out.println("");
			for(int j=0;j<this.steinerTree.length;j++){
				if(this.steinerTree[i][j])
					System.out.print(1+" ");
				else
					System.out.print(0 +" ");
			}
			System.out.print("<- Childs of " + i);
		}
	}
	
	
	// Computes the amount of Msgs for each edge
	public void amountDatainSteinerTree(){
		String group1;
		String group2;
		this.msgs = new double[this.weightedGraph.length][this.weightedGraph.length];		
		
		// Start assigning 0 msgs for all the edges
		for(int i=0;i<this.msgs.length;i++){ 
			for(int j=0;j<this.msgs.length;j++){
				this.msgs[i][j]=0;
			}
		}
		
		
		//Assign 1 msg for all edges that: (1) belongs to the steinerTree, (2) the endpoints belongs to the same group, (3) belongs to active groups
		// These edges are the intra group edges
		//System.out.println("\n\n");
		for(int i=0;i<this.msgs.length;i++){ 
			for(int j=0;j<this.msgs.length;j++){
				if(this.steinerTree[i][j]){ // 1
					if(this.s5.fromSameGroup(i, j)==true){ //2 
						group1 = this.s5.getDevice(i).getFirstGroup();
						if(this.s5.getAllCommunicatingGroups().contains(group1)){ // 3
							this.msgs[i][j]=1;
							//System.out.println(i +" and "+ j+ " are nodes that belongs to the same group  "+group1+ " and it is active "+this.s1.getAllCommunicatingGroups().contains(group1));
						} // end if 3
					} // end if 2
				} // end if 1					
			} // end for j
		} // end for i
		
		
		//Every group root adds one msg in the path to the the sink
		// The roots are the child nodes that belongs to an active group and the parent belong to another group, including the inactive group.
		//System.out.println("\n\n");
		for(int i=0;i<this.msgs.length;i++){ 
			for(int j=0;j<this.msgs.length;j++){
				if(this.steinerTree[i][j]){ // 1- Belong to the steiner tree
					if(this.s5.fromSameGroup(i, j)==false){ //2 - child and parent belong to dff groups
						group1 = this.s5.getDevice(j).getFirstGroup(); 
						//System.out.println(group1+" is active");
						if(this.s5.getAllCommunicatingGroups().contains(group1)){ // 3 - the group of the child node is active 
							//System.out.print("\n Increment one msg in all edges belonging to the path: " + j + " to GW.");
							incrementMsgPathtoGw(j); // Update the msg of the child, which is the j and not the i
						} // end if 3
					} // end if 2
				} // end if 1					
			} // end for j
		} // end for i
		
	}
	
	//Add one msg for all edges that belong to the path to reach the GW
	public void incrementMsgPathtoGw(int indexNode){
		int child=indexNode;
		int parent=0;
		
		while(child != 0){
			//for(int h=0;h<5;h++){
			//Find the parent of the child
			for(int i=0;i<this.steinerTree.length;i++){
				if(this.steinerTree[i][child]){
					parent=i;
					//System.out.print("\n Parent of "+child+" is "+ parent);
					this.msgs[parent][child]=this.msgs[parent][child]+1;
					child=parent;
				}
			}

		}
			
	}
	
	
	public void printMsgSteinerTree(){
		int test;
		System.out.println("\n\n");
			for(int i=0;i<this.msgs.length;i++){
				System.out.println("");
				for(int j=0;j<this.msgs.length;j++){
						System.out.print((int) this.msgs[i][j]+" ");
			}
		}
	}
	
	
	public void printWeightedGraph(){
	System.out.print("\n\nPrinting weighted graph");
	for (int i=0;i<this.weightedGraph.length;i++){
		System.out.println();
		for(int j=0;j<this.weightedGraph.length;j++)
			System.out.print(this.weightedGraph[i][j]+" ");
	}
}
	
	// Use the msgSteinerTree to compute the energy
	public void deductEnergy(){
		float distance; //Distance
		float nMsgs;
		int sender;
		int receiver;
		double TXcost;
		double RXcost;
		
		for(int i=0; i<this.msgs.length;i++){
			for(int j=0;j<this.msgs.length;j++){
				if(this.msgs[j][i]>0){
					sender = i;
					receiver = j;
					distance = this.s5.findDistance(sender, receiver);
					nMsgs = (float) this.msgs[j][i]; 
					TXcost=this.computeEnergyTx(distance, nMsgs);
					RXcost=this.computeEnergyRx(distance, nMsgs);
					this.residualEnergy[sender] = this.residualEnergy[sender] - TXcost;
					//System.out.print("\nDevice "+sender+" Tx to "+ receiver + " " + nMsgs + " msgs consuming " + TXcost);
					this.residualEnergy[receiver] = this.residualEnergy[receiver] - RXcost;
					//System.out.print("\nDevice "+receiver+" Rx from "+ sender + " " + nMsgs + " msgs consuming " + RXcost);
					
					if(this.s5.fromSameGroup(sender, receiver)==false){
						this.sumInterEnergy = this.sumInterEnergy + TXcost +RXcost;
						//System.out.print(" Inter group communication");
					}
					
					else if((this.s5.fromSameGroup(sender, receiver)==true) && (this.s5.getAllCommunicatingGroups().contains(this.s5.getDevice(sender).getFirstGroup())==false)){ // If the nodes are from the same group but the group is not active, so it is inter group communication
						this.sumInterEnergy = this.sumInterEnergy + TXcost +RXcost;
						//System.out.print(" Inter group communication");
					}
					
					else {
						this.sumIntraEnergy = this.sumIntraEnergy + TXcost +RXcost;
						//System.out.print(" Intra group communication");

					}
					
				}
			}
		}

	}
	
	
	
	public double computeEnergyTx(float distance, float nMsgs){
		// Tx = nbits.50nJ/bit + nbits.100pJ/bit/m * distance^2
		double elec=50*(Math.pow(10, -9)); // Energy required to run the circuit 50nJ/bit
		double amp = 100*(Math.pow(10, -12)); // Energy required to tx
		float singleMsgLength = 4 * 8; // in bits
		float headerLength = 12 * 8; // in bits
		double nBits = headerLength + (singleMsgLength * nMsgs);
		double turnonCost = 0.000022;//Cost to turn on the device and the radio (in Joules)
		double energyCost = (nBits*elec) + (nBits*amp*Math.pow(distance, 2))+turnonCost;
		
		return energyCost;
	}

	public double computeEnergyRx(float distance, float nMsgs){
		// Rx = nbits.50nJ/bit
		double elec=50*(Math.pow(10, -9)); // Energy required to run the circuit 50nJ/bit
		float singleMsgLength = 4 * 8; // in bits
		float headerLength = 12 * 8; // in bits
		double nBits = headerLength + (singleMsgLength * nMsgs);
		double turnonCost = 0.000022;//Cost to turn on the device and the radio (in Joules)
		double energyCost = nBits*elec + turnonCost;
		
		return energyCost;
	}
	
	

	



	
}
